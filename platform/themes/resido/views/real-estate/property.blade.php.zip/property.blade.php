@php
    Theme::asset()->usePath()->add('leaflet-css', 'plugins/leaflet.css');
    Theme::asset()->usePath()->add('jquery-bar-rating', 'plugins/jquery-bar-rating/themes/fontawesome-stars.css');
    Theme::asset()->container('footer')->usePath()->add('leaflet-js', 'plugins/leaflet.js');
    Theme::asset()->usePath()->add('magnific-css', 'plugins/magnific-popup.css');
    Theme::asset()->container('footer')->usePath()->add('magnific-js', 'plugins/jquery.magnific-popup.min.js');
    Theme::asset()->container('footer')->usePath()->add('property-js', 'js/property.js');
    Theme::asset()->container('footer')->usePath()->add('jquery-bar-rating-js', 'plugins/jquery-bar-rating/jquery.barrating.min.js');
    Theme::asset()->container('footer')->usePath()->add('wishlist', 'js/wishlist.js', [], []);
    $headerLayout = MetaBox::getMetaData($property, 'header_layout', true);
    $headerLayout = $headerLayout ?: 'layout-1';
@endphp
{!! Theme::partial('real-estate.properties.headers.' . $headerLayout, compact('property')) !!}

<!-- ============================ Property Detail Start ================================== -->
<div class="sides_list_property_detail py-3 px-7">
    <h3 class="mb-0">
        {!! $property->name !!}
        </h3>
        <div class="row py-3">
            <div class="col">
                <span>
                            <i class="ti-location-pin"></i>
                           {{ $property->city->state->name }}, {{ $property->city->name }}  
                    </span>

            </div>
            <div class="col">
           <span>
           <i class="far fa-clock"></i>
                             {!! $property->created_at !!}
                    </span>
            </div>

        </div>
        <div class="row lists_property_price py-0">
            <div class="lists_property_types">
                <div class="property_types_vlix">للبدل</div>
                <span class="pr-3"><i class="far fa-money-bill-alt"></i> كاش</span> 
                <!--  property price 
                <h3 class="prt-price-fix">{{ $property->price_html }}</h3> -->
                <span class="ml-3"><i class="far fa-building"></i> {!! $property->category->name !!}</span>
            </div>

        </div>
</div>
<!--  end property name -->
<!-- start gray section-->
<div class="property-details bg-gray px-7">
    <div class="accordion accordion-flush" id="accordionFlushExample">
        <div class="row accordion-item bg-transparent">
            <h2 class="col accordion-header" id="flush-headingOne">
                <button class="gray-color accordion-button bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                    المواصفات
                </button>
            </h2>
            <h2 class="col accordion-header" id="flush-headingTwo">
                <button class="gray-color accordion-button collapsed bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                    التفاصيل
                </button>
            </h2>
            <h2 class="col accordion-header" id="flush-headingThree">
                <button class="gray-color accordion-button collapsed bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                    الموقع
                </button>
            </h2>
            <h2 class="col accordion-header" id="flush-headingfour">
                <button class="gray-color accordion-button collapsed bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsefour" aria-expanded="false" aria-controls="flush-collapsefour">
                    الصور
                </button>
            </h2>

        </div>
        <div class="accordion-item bg-transparent">
            <div id="flush-collapseOne" class="show accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body px-0">
                    {!! $property->description !!}
                </div>
            </div>
            <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body px-0">{!! $property->content !!}</div>
            </div>
            
            
<!-- Single Block Wrap -->            
            <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body px-0">

                        <div class="block-body">
                            @if ($property->latitude && $property->longitude)
                                {!! Theme::partial('real-estate.elements.traffic-map-modal', ['location' => $property->location . ', ' . $property->city_name]) !!}
                            @else
                                {!! Theme::partial('real-estate.elements.gmap-canvas', ['location' => $property->location]) !!}
                            @endif
                        </div>

                </div>
            </div>
            
<!-- start gray section -->            
            <div id="flush-collapsefour" class="accordion-collapse collapse" aria-labelledby="flush-headingfour" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body px-0">
                     
                     <div id="clSev" class="panel-collapse collapse show">
            <div class="block-body">
                <ul class="list-gallery-inline">
                                       @foreach($property->images as $image)           
       
                            <li><a href="/public/storage/{{$image}}" class="mfp-gallery">
                                <img src="/public/storage/{{$image}}" data-src="" class="img-fluid mx-auto lazy" alt=""  /></a>
                            
                        </li>
                              @endforeach            
                                    </ul>
            </div>
        </div>
                     
                     
                </div>
            </div>
        </div>

    </div>
</div>
<!-- end gray section -->
<!-- start auction -->
<div class="auctions px-7 pt-3">
 
    <a href="{{url('/properties/'.$property->id.'/bids')}}" class="text-decoration-underline d-block blue-color">جميع المزايدات( {{ $property->reviews_count }})</a>
    @foreach($propertyBidds as $bid)
        <div class="col-sm-12">
            
            
            
            <div class="property-listing property-1 my-3 border shadow-none border-radius-none">
                <div class="listing-img-wrapper">
                    <div class="listing-content">
                        <div class="listing-detail-wrapper-box">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail">
                                    <h4 class="d-flex align-items-center listing-name blue-color mb-2 d-flex flex-row">
                                        <p>
                                            <i class="fas fa-plus"></i>
                                        </p>
                                        <p>
                                            <span class="d-block">{{$bid->star}}</span>
                                            <a class="blue-color" href="#" title="{{$bid->comment}}">{{$bid->comment}}</a>
                                        </p>
                                    </h4>
                                </div> 
                                <div class="list-price d-flex flex-row">
                                     <h6 class="fs-14px gray-color font-weight-bold listing-card-info-price d-inline-block w-50"><i class="far fa-user"></i> {{$bid->account->username}}</h6>

                                    <div class="d-inline-block w-50">

                                        <div class="time_bid">
                                            
                                        {{-- <pre>      </pre><span class="gray-color">{{$bid->star}}</span>--}}
                                            <span class="gray-color fs-14px"><i class="far fa-clock"></i> {{$bid->created_at}}</span></div>
                                         </div> 
                                        </div>
                                    </div>
                                </div> 
            </div></div></div>
          
        </div>
    @endforeach


</div>
<!-- end auction -->
<!-- start add auction -->
<!-- Button trigger modal -->
<div class="px-7 ">
    <button type="button" data-bs-toggle="modal" data-bs-target="#creditModal" class="mb-4 rounded-pill bg-blue row w-100 mx-auto d-block border-0 btn btn-primary">
        أضف مزايدة
    </button>
</div>

<!-- start add auction modal -->
<div class="modal fade" id="AddAcutionModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header border-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-0">
                <h3>أختار نوع المزايدة</h3>
                <form action="{{url('/reviews/create')}}" method="POST" id="frmhomesearch">
                    {{csrf_field()}}
                    <div class="hero-search-content side-form">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <select class="form-control bg-white" name="replacement" required required  id="doc_type"     oninvalid="this.setCustomValidity('برجاء اختيار من القائمة')" oninput="setCustomValidity('')">
                                        <option value="">أختار نوع المزايدة</option>
                                        <option value="بيت حكومي">بيت حكومي</option>
                                        <option value="كاش + بيت حكومي">كاش + بيت حكومي</option>
                                        <option value="قسيمة">قسيمة</option>
                                        <option value="كاش + قسيمة">كاش + قسيمة</option>
                                        <option value="اسكان">اسكان</option>
                                        <option value="كاش + اسكان">كاش + اسكان</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <select class="form-control bg-white" name="propertyName" required required  id="doc_type"     oninvalid="this.setCustomValidity('برجاء اختيار من القائمة')" oninput="setCustomValidity('')">
                                        <option value="">أختار من قائمتك</option>
                                        @foreach($authorProperties as $authorProperty)
                                            <option value="{{$authorProperty->name}}">{{$authorProperty->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <p class="position-relative">
                                    <i class="fas fa-minus minus"  id="minus1"></i>
                                    <input type="text" value="1" class="form-control bg-white text-center qty w-100 position-relative" name="cash" required/>
                                    <i class="fas fa-plus add" id="add1"></i>
                                </p>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" value="{{$property->toArray()['id']}}" name="property_id">
                    <div class="modal-footer border-0">
                        <input type="submit" value="أضف مزايدة" class="btn btn-primary rounded-pill bg-blue row w-75 mx-auto d-block border-0 btn btn-primary"  data-bs-dismiss="modal disabled">
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<!-- end add auction modal-->
<!-- start credit modal -->
<div class="modal fade" id="creditModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header border-0">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-0">
                    {{csrf_field()}}
                    <div class="hero-search-content side-form">
                        <div class="row">
                            <h3 class="blue-color my-3">سيتم خصم 1 دينار كويتى</h3>
                            <p> حتى تستطيع ان تزايد في اي من المزادات المتاحة في الموقع وسيتم سحب هذا المبلغ من المحفظة الخاصة بك كل مزايدة وإذا لم يكن لديك رصيد أشحن المحفظة.</p>
                            <a href="/account/packages"> <span class="blue-color fs-14px">أشحن المحفظة الان </span></a>
                        </div>
                    </div>
                    
                    <div class="modal-footer border-0">
                        <button type="button" data-bs-toggle="modal" data-bs-target="#AddAcutionModel" class="charge-btn mb-4 rounded-pill bg-blue row w-100 mx-auto d-block border-0 btn btn-primary">
        موافق
    </button>
                    </div>
                
            </div>

        </div>
    </div>
</div>
<!-- end credit modal -->
<script>
    $(document).ready(function(){
        $(".add").on("click", function () {
            var $qty = $(this).closest("p").find(".qty");
            var currentVal = parseInt($qty.val());
            if (!isNaN(currentVal)) {
                $qty.val(currentVal + 1);
            }
        });
        $(".minus").on("click", function () {
            var $qty = $(this).closest("p").find(".qty");
            var currentVal = parseInt($qty.val());
            if (!isNaN(currentVal) && currentVal > 0) {
                $qty.val(currentVal - 1);
            }
        });
        $(".charge-btn").click(function(){
            $("#creditModal").hide();
        });
        $("#AddAcutionModel .btn-close").click(function(){
             location.reload();
        })
    })

</script>


@if ($property->latitude && $property->longitude)
    <div
        data-magnific-popup="#trafficMap"
        data-map-id="trafficMap"
        data-popup-id="#traffic-popup-map-template"
        data-map-icon="{{ $property->map_icon }}"
        data-center="{{ json_encode([$property->latitude, $property->longitude]) }}">
    </div>
@endif

<script id="traffic-popup-map-template" type="text/x-custom-template">
    {!! Theme::partial('real-estate.properties.map', ['property' => $property]) !!}
</script>
<!-- ============================ Property Detail End ================================== -->
