@php
    $layout = theme_option('properties_page_layout');

    $requestLayout = request()->input('layout');
    if ($requestLayout && in_array($requestLayout, array_keys(get_properties_page_layout()))) {
        $layout = $requestLayout;
    }

    $layout = ($layout && in_array($layout, array_keys(get_properties_page_layout()))) ? $layout : 'sidebar';

    $viewType = request()->input('view', 'grid');
    $gridClass = 'col-lg-12 col-md-12';
    $gridItemClass = 'col-lg-6 col-md-12';

    if ($layout !== 'full' && $layout !== 'grid_full') {
        $gridClass = 'col-lg-8 col-md-12';
    }

    switch ($layout) {
        case 'grid_sidebar':
        case 'grid_map':
        case 'sidebar':
        case 'map':
            if($viewType == 'list') {
                 $gridItemClass = 'col-lg-12 col-md-12';
            }
            break;

        case 'full':
            $viewType = 'list';
            break;

        case 'grid_full':
            if ($viewType == 'list') {
                $gridItemClass = 'col-lg-6 col-md-12';
            } else {
                $gridItemClass = 'col-lg-4 col-md-6 col-sm-12';
            }
            break;
    }
@endphp

@if ($layout == 'half_map')
    @php
        Theme::asset()
            ->usePath()
            ->add('leaflet-css', 'plugins/leaflet.css');
        Theme::asset()
            ->container('footer')
            ->usePath()
            ->add('leaflet-js', 'plugins/leaflet.js');
        Theme::asset()
            ->container('footer')
            ->usePath()
            ->add('leaflet.markercluster-src-js', 'plugins/leaflet.markercluster-src.js');
    @endphp
    <div class="half-map container-fluid max-w-screen-2xl">
        <div class="fs-content">
            <form action="{{ route('public.properties') }}" method="get" id="ajax-filters-form">
                <input type="hidden" name="page" data-value="{{ $properties->currentPage() }}">
                <input type="hidden" name="layout" value="{{ request()->input('layout') }}">
                <div class="row">
                    <div class="fs-inner-container1 col-md-7" id="properties-list">
                        @include(Theme::getThemeNamespace('views.real-estate.includes.filters-halfmap'))
                        <div class="list-layout data-listing position-relative">
                            {!! Theme::partial('real-estate.properties.items', compact('properties')) !!}
                        </div>
                    </div>
                    <div class="fs-left-map-box1 col-md-5">
                        <div class="rightmap h-100">
                            <div id="map" data-type="{{ request()->input('type') }}"
                                 data-url="{{ route('public.ajax.properties.map') }}"
                                 data-center="{{ json_encode([43.615134, -76.393186]) }}"></div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="clearfix"></div>
@else


    <!-- ============================ All Property ================================== -->
   

 <!--  start top search bar-->

<div class="full-search-2 eclip-search italian-search hero-search-radius shadow-hard mt-5">
<form action="https://badal.sahla-ad.com/public/properties" method="GET" id="frmhomesearch">
<div class="hero-search-content">
    <div class="row">
        <div class="col-lg-5 col-md-4 col-10 p-0 elio">
            <div class="form-group">
                <div class="input-with-icon">
                    <div class="input-with-icon">
                    <input type="text" name="k" value="" placeholder="Search for a location" class="form-control d-inline-block"> 
                    <img src="https://badal.sahla-ad.com/public/themes/resido/img/pin.svg" width="20">
                    </div>
                </div>
            </div>
        </div> 
        <div class="col-lg-1 col-md-1 col-2">
            <div class="filter_search_opt">
                        <a href="javascript:void(0);" class="open_search_menu"><i class="ml-0 fas fa-filter"></i></a>
            </div>
            <!--<div class="form-group">-->
            <!--    <a data-bs-toggle="collapse" data-parent="#search" data-bs-target="#advance-search" href="javascript:void(0);" aria-expanded="false" aria-controls="advance-search" class="collapsed ad-search">-->
            <!--    <i class="fa fa-sliders-h"></i>-->
            <!--    </a>-->
            <!--</div>-->
        </div> 
     </div> 
        <div class="col-lg-2 col-md-3 col-sm-12">
            <div class="form-group">
                <button type="submit" class="btn search-btn">Search
                </button>
            </div>
        </div>
   
    <div id="advance-search" aria-expanded="false" role="banner" class="collapse"><div class="row"><div class="col-lg-4 col-md-4 col-sm-12">
<div class="form-group mb-2"><div class="input-with-icon"><select data-placeholder="City" data-url="https://badal.sahla-ad.com/public/ajax/cities" name="city_id" id="city_id" class="form-control city_id select2-hidden-accessible" data-select2-id="select2-data-city_id" tabindex="-1" aria-hidden="true">
</select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="select2-data-9-yjw6" style="width: auto;"><span class="selection">
<span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-city_id-container" aria-controls="select2-city_id-container"><span class="select2-selection__rendered" id="select2-city_id-container" role="textbox" aria-readonly="true" title="City">
<span class="select2-selection__placeholder">City</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span>
<span class="dropdown-wrapper" aria-hidden="true"></span></span> <i class="ti-location-pin"></i></div></div></div> <div class="col-lg-4 col-md-4 col-sm-12">
<div class="form-group mb-2"><div class="input-with-icon"><select id="select-bedroom" data-placeholder="Bedroom" name="bedroom" class="form-control select2-hidden-accessible" data-select2-id="select2-data-select-bedroom" tabindex="-1" aria-hidden="true">
<option value="" data-select2-id="select2-data-2-myxv">&nbsp;</option> <option value="1">



                    1
                </option> <option value="2">
                    2
                </option> <option value="3">
                    3
                </option> <option value="4">
                    4
                </option> <option value="5">
                    5
                </option></select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="select2-data-1-udfz" style="width: auto;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-select-bedroom-container" aria-controls="select2-select-bedroom-container"><span class="select2-selection__rendered" id="select2-select-bedroom-container" role="textbox" aria-readonly="true" title="Bedroom"><span class="select2-selection__placeholder">Bedroom</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span> <i class="fas fa-bed"></i></div></div></div> <div class="col-lg-4 col-md-4 col-sm-12"><div class="form-group mb-2"><div class="input-with-icon"><select id="select-bathroom" data-placeholder="Bathroom" name="bathroom" class="form-control select2-hidden-accessible" data-select2-id="select2-data-select-bathroom" tabindex="-1" aria-hidden="true"><option value="" data-select2-id="select2-data-4-psoa">&nbsp;</option> <option value="1">
                    1
                </option> <option value="2">
                    2
                </option> <option value="3">
                    3
                </option> <option value="4">
                    4
                </option> <option value="5">
                    5
                </option></select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="select2-data-3-4w7y" style="width: auto;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-select-bathroom-container" aria-controls="select2-select-bathroom-container"><span class="select2-selection__rendered" id="select2-select-bathroom-container" role="textbox" aria-readonly="true" title="Bathroom"><span class="select2-selection__placeholder">Bathroom</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span> <i class="fas fa-bath"></i></div></div></div></div> <div class="row"><div class="col-lg-3 col-md-6 col-sm-6"><div class="form-group simple mb-2"><select id="minprice" data-placeholder="No Min" name="min_price" class="form-control select2-hidden-accessible" data-select2-id="select2-data-minprice" tabindex="-1" aria-hidden="true"><option value="" data-select2-id="select2-data-6-0klb">&nbsp;</option> <option value="500">
                    500
                </option> <option value="1000">
                    1000
                </option> <option value="2000">
                    2000
                </option> <option value="5000">
                    5000
                </option> <option value="10000">
                    10000
                </option></select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="select2-data-5-gdgz" style="width: auto;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-minprice-container" aria-controls="select2-minprice-container"><span class="select2-selection__rendered" id="select2-minprice-container" role="textbox" aria-readonly="true" title="No Min"><span class="select2-selection__placeholder">No Min</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span></div></div> <div class="col-lg-3 col-md-6 col-sm-6"><div class="form-group simple mb-2"><select id="maxprice" data-placeholder="No Max" name="max_price" class="form-control select2-hidden-accessible" data-select2-id="select2-data-maxprice" tabindex="-1" aria-hidden="true"><option value="" data-select2-id="select2-data-8-m3yx">&nbsp;</option> <option value="1000">
                    1000
                </option> <option value="2000">
                    2000
                </option> <option value="5000">
                    5000
                </option> <option value="10000">
                    10000
                </option> <option value="50000">
                    50000
                </option></select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="select2-data-7-txwe" style="width: auto;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-maxprice-container" aria-controls="select2-maxprice-container"><span class="select2-selection__rendered" id="select2-maxprice-container" role="textbox" aria-readonly="true" title="No Max"><span class="select2-selection__placeholder">No Max</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span></div></div> <div class="col-lg-3 col-md-6 col-sm-6"><div class="form-group mb-2"><input type="text" name="min_area" value="" placeholder="Min Area" class="form-control"></div></div> <div class="col-lg-3 col-md-6 col-sm-6"><div class="form-group mb-2"><input type="text" name="max_area" value="" placeholder="Max Area" class="form-control"></div></div></div> <div class="row"><div class="col-lg-12 col-md-12 col-sm-12 mt-3"><h4 class="text-dark">Amenities &amp; Features</h4> <ul class="no-ul-list second-row"><li><input id="features-0" name="features[]" type="checkbox" value="1" class="input-filter checkbox-custom"> <label for="features-0" class="checkbox-custom-label">Wifi</label></li> <li><input id="features-1" name="features[]" type="checkbox" value="2" class="input-filter checkbox-custom"> <label for="features-1" class="checkbox-custom-label">Parking</label></li> <li><input id="features-2" name="features[]" type="checkbox" value="3" class="input-filter checkbox-custom"> <label for="features-2" class="checkbox-custom-label">Swimming pool</label></li> <li><input id="features-3" name="features[]" type="checkbox" value="4" class="input-filter checkbox-custom"> <label for="features-3" class="checkbox-custom-label">Balcony</label></li> <li><input id="features-4" name="features[]" type="checkbox" value="5" class="input-filter checkbox-custom"> <label for="features-4" class="checkbox-custom-label">Garden</label></li> <li><input id="features-5" name="features[]" type="checkbox" value="6" class="input-filter checkbox-custom"> <label for="features-5" class="checkbox-custom-label">Security</label></li> <li><input id="features-6" name="features[]" type="checkbox" value="7" class="input-filter checkbox-custom"> <label for="features-6" class="checkbox-custom-label">Fitness center</label></li> <li><input id="features-7" name="features[]" type="checkbox" value="8" class="input-filter checkbox-custom"> <label for="features-7" class="checkbox-custom-label">Air Conditioning</label></li> <li><input id="features-8" name="features[]" type="checkbox" value="9" class="input-filter checkbox-custom"> <label for="features-8" class="checkbox-custom-label">Central Heating  </label></li> <li><input id="features-9" name="features[]" type="checkbox" value="10" class="input-filter checkbox-custom"> <label for="features-9" class="checkbox-custom-label">Laundry Room</label></li> <li><input id="features-10" name="features[]" type="checkbox" value="11" class="input-filter checkbox-custom"> <label for="features-10" class="checkbox-custom-label">Pets Allow</label></li> <li><input id="features-11" name="features[]" type="checkbox" value="12" class="input-filter checkbox-custom"> <label for="features-11" class="checkbox-custom-label">Spa &amp; Massage</label></li></ul></div></div></div></div></form></div>
  
    <!--  end top search bar -->



 <!--  start top slider search page-->
    <div class="my-3 three-slider-buttons d-flex">
             <div class="rounded-pill btn gray-color border mx-2 font-weight-bold"><a href="/public/properties?k=&category_id=13"> <i class="fas fa-building"></i> بيت حكومي </div></a>
             <div class="rounded-pill btn gray-color border mx-2 font-weight-bold"><a href="/public/properties?k=&category_id=14"> <i class="fas fa-clipboard"></i> طلب أسكان  </div></a>
              <div class="rounded-pill btn gray-color border mx-2 font-weight-bold"><a href="/public/properties?k=&category_id=15"> <i class="far fa-id-card"></i> قسيمة  </div></a>


    </div>
    <!--  end top slider search page -->


   <!-- start accordion section -->
    <div class="property-details px-7 ">
        <div class="search-accordion  accordion accordion-flush " id="accordionFlushExample">
            <div class="mb-3 row accordion-item bg-transparent list-group list-group-horizontal">
                <h2 class="py-0 list-group-item col accordion-header" id="flush-headingOne">
                    <button class="gray-color accordion-button bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                        البحث العادي
                    </button>
                </h2>
                <h2 class="py-0 list-group-item col accordion-header" id="flush-headingTwo">
                <button class="gray-color accordion-button collapsed bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                   البحث بخرائط جوجل
                </button>
                </h2>
                <h2 class="py-0 list-group-item col accordion-header" id="flush-headingThree">
                <button class="gray-color accordion-button collapsed bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                    البحث بالمخططات
                </button>
                </h2>
            </div>
      
            <div class="accordion-item bg-transparent">
               <div id="flush-collapseOne" class="show accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body px-0">
                            <div class="row list-layout">
                            
                            </div>                    </div>
                </div>
                <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body px-0">
                    <p>
                    <div style="height: 400px; width: 100%; position: relative; text-align: right;">
                        <div  style="height: 400px; width: 100%; overflow: hidden; background: none!important;">
                            {!! do_shortcode('[hero-banner-style-map][/hero-banner-style-map]') !!}

                        </div>
                    </div>
                    </p>
                </div>                </div>
                <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body px-0">
                    <p>
                    <div style="height: 400px; width: 100%; position: relative; text-align: right;">
                        <div  style="height: 400px; width: 100%; overflow: hidden; background: none!important;">
                            <iframe width="100%" height="500" src="https://maps.google.com/maps?q=10 St, Al Jahra, Kuwait%20&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                    frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                        </div>
                    </div>
                    </p>
                </div>
                </div>
            </div>

        </div>
    </div> 
    
   <!-- end accordion section--> 
    <section class="gray">
        <div class="container">

          <!--  <div class="row">
                <div class="col-2">
                    <div class="filter_search_opt">
                        <a href="javascript:void(0);" class="open_search_menu"><i class="ml-0 fas fa-filter"></i></a>
                    </div>
                </div>
            </div> --> 
            


            <div class="row">
         

                <div class="{{ $gridClass }} list-layout">
                    <div class="row justify-content-center">
                        @include(Theme::getThemeNamespace('views.real-estate.includes.sorting-box'))
                    </div>

                    <div class="row">
                        @foreach ($properties as $property)
                            <div class="{{ $gridItemClass }}">
                                @if (strpos($viewType, 'grid') !== false)
                                    {!! Theme::partial('real-estate.properties.item-list', compact('property')) !!}
                                @else
                                    {!! Theme::partial('real-estate.properties.item-grid', compact('property')) !!}
                                @endif
                            </div>
                            <!-- End Single Property -->
                        @endforeach
                    </div>

                    <!-- Pagination -->
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <nav class="d-flex justify-content-center pt-3" aria-label="Page navigation">
                                {!! $properties->withQueryString()->onEachSide(1)->links() !!}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endif

<script id="traffic-popup-map-template" type="text/x-custom-template">
    {!! Theme::partial('real-estate.properties.map-popup', ['property' => get_object_property_map()]) !!}
</script>
<script>
$(document).ready(function(){
    $(".search-accordion h2").click(function(){
        $(".search-accordion h2").css("border-color","#00000020")
        $(this).css("border-color","#1266e3")
    })
    $(".search-accordion .list-group-horizontal,.three-slider-buttons").slick({
          slidesToShow: 2,
          slidesToScroll: 1,
          prevArrow: false,
          nextArrow: false
    });

})

</script>
