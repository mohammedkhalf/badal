@include(Theme::getThemeNamespace('views.real-estate.includes.properties-page-title'))
@include(Theme::getThemeNamespace('views.real-estate.includes.properties-list'))
