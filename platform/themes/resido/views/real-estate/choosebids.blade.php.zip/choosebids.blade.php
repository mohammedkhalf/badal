

    <div class="clearfix"></div>
    <!-- start page content -->
    <div id="app">

        <section>
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <div class="sec-heading center mb-0">
                            <h4 class="gray-color text-center">جميع المزادات</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="scontent">
                            <h1 class="blue-color text-center">{!! $property->name !!}</h1>
                            <form action="/account/properties/properetyUpdatePrice/{{$property->id}}" method="POST" id="frmhomesearch">
                                @csrf
                                <div class="hero-search-content side-form">
                                    <div class="row">
                                        <div class="col-12">
<div class="form-group">
                                                <select class="form-control bg-white" name="replacement">
                                                    <option value="">أختار نوع المزايدة</option>
                                                    @foreach($PropertyReplacement as $PR)
                                                    <option value="{{$PR->id}}" {{$PR->id == $property->replacement_id ? 'selected': ''}}>{{$PR->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <p class="position-relative">
                                                <i class="fas fa-minus minus" id="minus1"></i>
                                                <input id="qty1" name="price" type="text" value="{{$property->price}}"
                                                    class="form-control bg-white text-center qty w-100 position-relative" />
                                                <i class="fas fa-plus add" id="add1"></i>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="px-7 ">
                                    <button type="submit"
                                        class="mb-4 rounded-pill bg-blue row w-100 mx-auto d-block border-0 btn btn-primary">
                                        تعديل السعر
                                    </button>
                                </div>
                            </form>
                            <!-- start bottom sections -->
                            @foreach($property->reviews as $P)
                            <div class="col-sm-12">
                                <div class="property-listing property-1 my-3 border shadow-none border-radius-none">
                                    <div class="listing-img-wrapper">
                                        <div class="listing-content">
                                            <div class="listing-detail-wrapper-box">
                                                <div class="listing-detail-wrapper">
                                                    <div class="listing-short-detail">
                                                        <h4 class="blue-color listing-name mb-2">
                                                            <a class="blue-color"
                                                                href=""
                                                                title="802 Madison Street Northwest">{{$P->comment}}</a>
                                                        </h4>
                                                    </div>
                                                    <div class="list-price">
                                                        <div>
                                                            <div class="time_bid">
                                                                <span class="gray-color fs-14px">
                                                             <i class="far fa-clock"></i> {{$P->created_at}}</span>
                                                            </div>
                                                        </div>
                                                        <h6 class="fs-14px gray-color font-weight-bold listing-card-info-price">
                                                            <i class="far fa-user"></i> {{$P->account->username}}</h6>
                                                    </div>
                                                    <form action="/account/properties/approveBidd/{{$P->id}}" method="GET" id="frmhomesearch">
                                                        @csrf
                                                    <div class="mt-3  mb-2 px-7 "><button type="submit" href="" class="rounded-pill bg-blue row w-100 mx-auto d-block border-0 btn btn-primary">
                                                        Choose
                                                    </button></div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach

                            <!-- end bottom sections -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- end page content -->



