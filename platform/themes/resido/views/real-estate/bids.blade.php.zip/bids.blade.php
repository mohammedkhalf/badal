{{--@include(Theme::getThemeNamespace('views.real-estate.includes.properties-page-title'))--}}
{{--@include(Theme::getThemeNamespace('views.real-estate.includes.properties-list'))--}}
    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, user-scalable=1"
          name="viewport" />
    <meta name="csrf-token" content="HtnhadFgNS5BmPCwPrhFch454mVvPfZbD2QDyaRA">

    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,600,700" rel="stylesheet" type="text/css">

    <style>
        :root {
            --primary-color: #2b4db9;
            --font-body: Muli, sans-serif;
            --font-heading: Jost, sans-serif;
        }
    </style>
    <script>
        $(document).ready(function () {
            $(".add").on("click", function () {
                var $qty = $(this).closest("p").find(".qty");
                var currentVal = parseInt($qty.val());
                if (!isNaN(currentVal)) {
                    $qty.val(currentVal + 1);
                }
            });
            $(".minus").on("click", function () {
                var $qty = $(this).closest("p").find(".qty");
                var currentVal = parseInt($qty.val());
                if (!isNaN(currentVal) && currentVal > 0) {
                    $qty.val(currentVal - 1);
                }
            });
        })


    </script>
    <script>
        "use strict";
        window.trans = {
            "Price": "Price",
            "Number of rooms": "Number of rooms",
            "Number of rest rooms": "Number of rest rooms",
            "Square": "Square",
            "No property found": "No property found",
            "million": "million",
            "billion": "billion",
            "in": "in",
            "Added to wishlist successfully!": "Added to wishlist successfully!",
            "Removed from wishlist successfully!": "Removed from wishlist successfully!",
            "I care about this property!!!": "I care about this property!!!",
            "See More Reviews": "See More Reviews",
            "Reviews": "Reviews",
            "out of 5.0": "out of 5.0",
            "service": "Service",
            "value": "Value for Money",
            "location": "Location",
            "cleanliness": "Cleanliness",
        }
        window.themeUrl = 'https://badal.sahla-ad.com/public/themes/resido';
        window.siteUrl = 'https://badal.sahla-ad.com/public';
        window.currentLanguage = 'en';
    </script>
    <link rel="shortcut icon" href="https://badal.sahla-ad.com/public/storage/badel-logo-03.png">
    <title>All Bids</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:site_name" content="">
    <meta property="og:title" content="allbids">
    <meta property="og:description" content="">
    <meta property="og:url" content="https://badal.sahla-ad.com/public/allbids">
    <meta property="og:type" content="article">
    <meta property="og:image" content="https://badal.sahla-ad.com/public/storage/general/screenshot.png">
    <meta name="twitter:title" content="allbids">
    <meta name="twitter:description" content="">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/vendor/core/plugins/language/css/language-public.css?v=1.0.0">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/animation.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/bootstrap/bootstrap.min.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/ion.rangeSlider.min.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/dropzone.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/select2.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/slick.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/slick-theme.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/font-awesome.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/icofont.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/light-box.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/line-icon.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/plugins/themify.css">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/themes/resido/css/style.css?v=1.11.0">
    <script src="https://badal.sahla-ad.com/public/themes/resido/plugins/jquery.min.js"></script>
    <link rel="alternate" href="https://badal.sahla-ad.com/public/ar/allbids" hreflang="ar" />
    <link type="application/atom+xml" rel="alternate" title="Properties feed"
          href="https://badal.sahla-ad.com/public/feed/properties">
    <link type="application/atom+xml" rel="alternate" title="Properties feed"
          href="https://badal.sahla-ad.com/public/ar/feed/properties">
    <link type="application/atom+xml" rel="alternate" title="Posts feed"
          href="https://badal.sahla-ad.com/public/feed/posts">
    <link type="application/atom+xml" rel="alternate" title="Posts feed"
          href="https://badal.sahla-ad.com/public/ar/feed/posts">
    <link media="all" type="text/css" rel="stylesheet"
          href="https://badal.sahla-ad.com/public/vendor/core/packages/theme/css/admin-bar.css">
    <link rel='stylesheet' type='text/css' property='stylesheet'
          href='//badal.sahla-ad.com/public/_debugbar/assets/stylesheets?v=1637196972&theme=auto'>
    <script type='text/javascript' src='//badal.sahla-ad.com/public/_debugbar/assets/javascript?v=1637196972'></script>
    <script type="text/javascript">jQuery.noConflict(true);</script>
    <script> Sfdump = window.Sfdump || (function (doc) { var refStyle = doc.createElement('style'), rxEsc = /([.*+?^${}()|\[\]\/\\])/g, idRx = /\bsf-dump-\d+-ref[012]\w+\b/, keyHint = 0 <= navigator.platform.toUpperCase().indexOf('MAC') ? 'Cmd' : 'Ctrl', addEventListener = function (e, n, cb) { e.addEventListener(n, cb, false); }; refStyle.innerHTML = '.phpdebugbar pre.sf-dump .sf-dump-compact, .sf-dump-str-collapse .sf-dump-str-collapse, .sf-dump-str-expand .sf-dump-str-expand { display: none; }'; (doc.documentElement.firstElementChild || doc.documentElement.children[0]).appendChild(refStyle); refStyle = doc.createElement('style'); (doc.documentElement.firstElementChild || doc.documentElement.children[0]).appendChild(refStyle); if (!doc.addEventListener) { addEventListener = function (element, eventName, callback) { element.attachEvent('on' + eventName, function (e) { e.preventDefault = function () { e.returnValue = false; }; e.target = e.srcElement; callback(e); }); }; } function toggle(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className, arrow, newClass; if (/\bsf-dump-compact\b/.test(oldClass)) { arrow = '▼'; newClass = 'sf-dump-expanded'; } else if (/\bsf-dump-expanded\b/.test(oldClass)) { arrow = '▶'; newClass = 'sf-dump-compact'; } else { return false; } if (doc.createEvent && s.dispatchEvent) { var event = doc.createEvent('Event'); event.initEvent('sf-dump-expanded' === newClass ? 'sfbeforedumpexpand' : 'sfbeforedumpcollapse', true, false); s.dispatchEvent(event); } a.lastChild.innerHTML = arrow; s.className = s.className.replace(/\bsf-dump-(compact|expanded)\b/, newClass); if (recursive) { try { a = s.querySelectorAll('.' + oldClass); for (s = 0; s < a.length; ++s) { if (-1 == a[s].className.indexOf(newClass)) { a[s].className = newClass; a[s].previousSibling.lastChild.innerHTML = arrow; } } } catch (e) { } } return true; }; function collapse(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className; if (/\bsf-dump-expanded\b/.test(oldClass)) { toggle(a, recursive); return true; } return false; }; function expand(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className; if (/\bsf-dump-compact\b/.test(oldClass)) { toggle(a, recursive); return true; } return false; }; function collapseAll(root) { var a = root.querySelector('a.sf-dump-toggle'); if (a) { collapse(a, true); expand(a); return true; } return false; } function reveal(node) { var previous, parents = []; while ((node = node.parentNode || {}) && (previous = node.previousSibling) && 'A' === previous.tagName) { parents.push(previous); } if (0 !== parents.length) { parents.forEach(function (parent) { expand(parent); }); return true; } return false; } function highlight(root, activeNode, nodes) { resetHighlightedNodes(root); Array.from(nodes || []).forEach(function (node) { if (!/\bsf-dump-highlight\b/.test(node.className)) { node.className = node.className + ' sf-dump-highlight'; } }); if (!/\bsf-dump-highlight-active\b/.test(activeNode.className)) { activeNode.className = activeNode.className + ' sf-dump-highlight-active'; } } function resetHighlightedNodes(root) { Array.from(root.querySelectorAll('.sf-dump-str, .sf-dump-key, .sf-dump-public, .sf-dump-protected, .sf-dump-private')).forEach(function (strNode) { strNode.className = strNode.className.replace(/\bsf-dump-highlight\b/, ''); strNode.className = strNode.className.replace(/\bsf-dump-highlight-active\b/, ''); }); } return function (root, x) { root = doc.getElementById(root); var indentRx = new RegExp('^(' + (root.getAttribute('data-indent-pad') || ' ').replace(rxEsc, '\\$1') + ')+', 'm'), options = { "maxDepth": 1, "maxStringLength": 160, "fileLinkFormat": false }, elt = root.getElementsByTagName('A'), len = elt.length, i = 0, s, h, t = []; while (i < len) t.push(elt[i++]); for (i in x) { options[i] = x[i]; } function a(e, f) { addEventListener(root, e, function (e, n) { if ('A' == e.target.tagName) { f(e.target, e); } else if ('A' == e.target.parentNode.tagName) { f(e.target.parentNode, e); } else { n = /\bsf-dump-ellipsis\b/.test(e.target.className) ? e.target.parentNode : e.target; if ((n = n.nextElementSibling) && 'A' == n.tagName) { if (!/\bsf-dump-toggle\b/.test(n.className)) { n = n.nextElementSibling || n; } f(n, e, true); } } }); }; function isCtrlKey(e) { return e.ctrlKey || e.metaKey; } function xpathString(str) { var parts = str.match(/[^'"]+|['"]/g).map(function (part) { if ("'" == part) { return '"\'"'; } if ('"' == part) { return "'\"'"; } return "'" + part + "'"; }); return "concat(" + parts.join(",") + ", '')"; } function xpathHasClass(className) { return "contains(concat(' ', normalize-space(@class), ' '), ' " + className + " ')"; } addEventListener(root, 'mouseover', function (e) { if ('' != refStyle.innerHTML) { refStyle.innerHTML = ''; } }); a('mouseover', function (a, e, c) { if (c) { e.target.style.cursor = "pointer"; } else if (a = idRx.exec(a.className)) { try { refStyle.innerHTML = '.phpdebugbar pre.sf-dump .' + a[0] + '{background-color: #B729D9; color: #FFF !important; border-radius: 2px}'; } catch (e) { } } }); a('click', function (a, e, c) { if (/\bsf-dump-toggle\b/.test(a.className)) { e.preventDefault(); if (!toggle(a, isCtrlKey(e))) { var r = doc.getElementById(a.getAttribute('href').substr(1)), s = r.previousSibling, f = r.parentNode, t = a.parentNode; t.replaceChild(r, a); f.replaceChild(a, s); t.insertBefore(s, r); f = f.firstChild.nodeValue.match(indentRx); t = t.firstChild.nodeValue.match(indentRx); if (f && t && f[0] !== t[0]) { r.innerHTML = r.innerHTML.replace(new RegExp('^' + f[0].replace(rxEsc, '\\$1'), 'mg'), t[0]); } if (/\bsf-dump-compact\b/.test(r.className)) { toggle(s, isCtrlKey(e)); } } if (c) { } else if (doc.getSelection) { try { doc.getSelection().removeAllRanges(); } catch (e) { doc.getSelection().empty(); } } else { doc.selection.empty(); } } else if (/\bsf-dump-str-toggle\b/.test(a.className)) { e.preventDefault(); e = a.parentNode.parentNode; e.className = e.className.replace(/\bsf-dump-str-(expand|collapse)\b/, a.parentNode.className); } }); elt = root.getElementsByTagName('SAMP'); len = elt.length; i = 0; while (i < len) t.push(elt[i++]); len = t.length; for (i = 0; i < len; ++i) { elt = t[i]; if ('SAMP' == elt.tagName) { a = elt.previousSibling || {}; if ('A' != a.tagName) { a = doc.createElement('A'); a.className = 'sf-dump-ref'; elt.parentNode.insertBefore(a, elt); } else { a.innerHTML += ' '; } a.title = (a.title ? a.title + '\n[' : '[') + keyHint + '+click] Expand all children'; a.innerHTML += elt.className == 'sf-dump-compact' ? '<span>▶</span>' : '<span>▼</span>'; a.className += ' sf-dump-toggle'; x = 1; if ('sf-dump' != elt.parentNode.className) { x += elt.parentNode.getAttribute('data-depth') / 1; } } else if (/\bsf-dump-ref\b/.test(elt.className) && (a = elt.getAttribute('href'))) { a = a.substr(1); elt.className += ' ' + a; if (/[\[{]$/.test(elt.previousSibling.nodeValue)) { a = a != elt.nextSibling.id && doc.getElementById(a); try { s = a.nextSibling; elt.appendChild(a); s.parentNode.insertBefore(a, s); if (/^[@#]/.test(elt.innerHTML)) { elt.innerHTML += ' <span>▶</span>'; } else { elt.innerHTML = '<span>▶</span>'; elt.className = 'sf-dump-ref'; } elt.className += ' sf-dump-toggle'; } catch (e) { if ('&' == elt.innerHTML.charAt(0)) { elt.innerHTML = '…'; elt.className = 'sf-dump-ref'; } } } } } if (doc.evaluate && Array.from && root.children.length > 1) { root.setAttribute('tabindex', 0); SearchState = function () { this.nodes = []; this.idx = 0; }; SearchState.prototype = { next: function () { if (this.isEmpty()) { return this.current(); } this.idx = this.idx < (this.nodes.length - 1) ? this.idx + 1 : 0; return this.current(); }, previous: function () { if (this.isEmpty()) { return this.current(); } this.idx = this.idx > 0 ? this.idx - 1 : (this.nodes.length - 1); return this.current(); }, isEmpty: function () { return 0 === this.count(); }, current: function () { if (this.isEmpty()) { return null; } return this.nodes[this.idx]; }, reset: function () { this.nodes = []; this.idx = 0; }, count: function () { return this.nodes.length; }, }; function showCurrent(state) { var currentNode = state.current(), currentRect, searchRect; if (currentNode) { reveal(currentNode); highlight(root, currentNode, state.nodes); if ('scrollIntoView' in currentNode) { currentNode.scrollIntoView(true); currentRect = currentNode.getBoundingClientRect(); searchRect = search.getBoundingClientRect(); if (currentRect.top < (searchRect.top + searchRect.height)) { window.scrollBy(0, -(searchRect.top + searchRect.height + 5)); } } } counter.textContent = (state.isEmpty() ? 0 : state.idx + 1) + ' of ' + state.count(); } var search = doc.createElement('div'); search.className = 'sf-dump-search-wrapper sf-dump-search-hidden'; search.innerHTML = ' <input type="text" class="sf-dump-search-input"> <span class="sf-dump-search-count">0 of 0<\/span> <button type="button" class="sf-dump-search-input-previous" tabindex="-1"> <svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1683 1331l-166 165q-19 19-45 19t-45-19L896 965l-531 531q-19 19-45 19t-45-19l-166-165q-19-19-19-45.5t19-45.5l742-741q19-19 45-19t45 19l742 741q19 19 19 45.5t-19 45.5z"\/><\/svg> <\/button> <button type="button" class="sf-dump-search-input-next" tabindex="-1"> <svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1683 808l-742 741q-19 19-45 19t-45-19L109 808q-19-19-19-45.5t19-45.5l166-165q19-19 45-19t45 19l531 531 531-531q19-19 45-19t45 19l166 165q19 19 19 45.5t-19 45.5z"\/><\/svg> <\/button> '; root.insertBefore(search, root.firstChild); var state = new SearchState(); var searchInput = search.querySelector('.sf-dump-search-input'); var counter = search.querySelector('.sf-dump-search-count'); var searchInputTimer = 0; var previousSearchQuery = ''; addEventListener(searchInput, 'keyup', function (e) { var searchQuery = e.target.value; /* Don't perform anything if the pressed key didn't change the query */ if (searchQuery === previousSearchQuery) { return; } previousSearchQuery = searchQuery; clearTimeout(searchInputTimer); searchInputTimer = setTimeout(function () { state.reset(); collapseAll(root); resetHighlightedNodes(root); if ('' === searchQuery) { counter.textContent = '0 of 0'; return; } var classMatches = ["sf-dump-str", "sf-dump-key", "sf-dump-public", "sf-dump-protected", "sf-dump-private",].map(xpathHasClass).join(' or '); var xpathResult = doc.evaluate('.//span[' + classMatches + '][contains(translate(child::text(), ' + xpathString(searchQuery.toUpperCase()) + ', ' + xpathString(searchQuery.toLowerCase()) + '), ' + xpathString(searchQuery.toLowerCase()) + ')]', root, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null); while (node = xpathResult.iterateNext()) state.nodes.push(node); showCurrent(state); }, 400); }); Array.from(search.querySelectorAll('.sf-dump-search-input-next, .sf-dump-search-input-previous')).forEach(function (btn) { addEventListener(btn, 'click', function (e) { e.preventDefault(); -1 !== e.target.className.indexOf('next') ? state.next() : state.previous(); searchInput.focus(); collapseAll(root); showCurrent(state); }) }); addEventListener(root, 'keydown', function (e) { var isSearchActive = !/\bsf-dump-search-hidden\b/.test(search.className); if ((114 === e.keyCode && !isSearchActive) || (isCtrlKey(e) && 70 === e.keyCode)) { /* F3 or CMD/CTRL + F */ if (70 === e.keyCode && document.activeElement === searchInput) { /* * If CMD/CTRL + F is hit while having focus on search input, * the user probably meant to trigger browser search instead. * Let the browser execute its behavior: */ return; } e.preventDefault(); search.className = search.className.replace(/\bsf-dump-search-hidden\b/, ''); searchInput.focus(); } else if (isSearchActive) { if (27 === e.keyCode) { /* ESC key */ search.className += ' sf-dump-search-hidden'; e.preventDefault(); resetHighlightedNodes(root); searchInput.value = ''; } else if ((isCtrlKey(e) && 71 === e.keyCode) /* CMD/CTRL + G */ || 13 === e.keyCode /* Enter */ || 114 === e.keyCode /* F3 */) { e.preventDefault(); e.shiftKey ? state.previous() : state.next(); collapseAll(root); showCurrent(state); } } }); } if (0 >= options.maxStringLength) { return; } try { elt = root.querySelectorAll('.sf-dump-str'); len = elt.length; i = 0; t = []; while (i < len) t.push(elt[i++]); len = t.length; for (i = 0; i < len; ++i) { elt = t[i]; s = elt.innerText || elt.textContent; x = s.length - options.maxStringLength; if (0 < x) { h = elt.innerHTML; elt[elt.innerText ? 'innerText' : 'textContent'] = s.substring(0, options.maxStringLength); elt.className += ' sf-dump-str-collapse'; elt.innerHTML = '<span class=sf-dump-str-collapse>' + h + '<a class="sf-dump-ref sf-dump-str-toggle" title="Collapse"> ◀</a></span>' + '<span class=sf-dump-str-expand>' + elt.innerHTML + '<a class="sf-dump-ref sf-dump-str-toggle" title="' + x + ' remaining characters"> ▶</a></span>'; } } } catch (e) { } }; })(document); </script>
    <style>
        .phpdebugbar pre.sf-dump {
            display: block;
            white-space: pre;
            padding: 5px;
            overflow: initial !important;
        }

        .phpdebugbar pre.sf-dump:after {
            content: "";
            visibility: hidden;
            display: block;
            height: 0;
            clear: both;
        }

        .phpdebugbar pre.sf-dump span {
            display: inline;
        }

        .phpdebugbar pre.sf-dump a {
            text-decoration: none;
            cursor: pointer;
            border: 0;
            outline: none;
            color: inherit;
        }

        .phpdebugbar pre.sf-dump img {
            max-width: 50em;
            max-height: 50em;
            margin: .5em 0 0 0;
            padding: 0;
            background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAAAAAA6mKC9AAAAHUlEQVQY02O8zAABilCaiQEN0EeA8QuUcX9g3QEAAjcC5piyhyEAAAAASUVORK5CYII=) #D3D3D3;
        }

        .phpdebugbar pre.sf-dump .sf-dump-ellipsis {
            display: inline-block;
            overflow: visible;
            text-overflow: ellipsis;
            max-width: 5em;
            white-space: nowrap;
            overflow: hidden;
            vertical-align: top;
        }

        .phpdebugbar pre.sf-dump .sf-dump-ellipsis+.sf-dump-ellipsis {
            max-width: none;
        }

        .phpdebugbar pre.sf-dump code {
            display: inline;
            padding: 0;
            background: none;
        }

        .sf-dump-public.sf-dump-highlight,
        .sf-dump-protected.sf-dump-highlight,
        .sf-dump-private.sf-dump-highlight,
        .sf-dump-str.sf-dump-highlight,
        .sf-dump-key.sf-dump-highlight {
            background: rgba(111, 172, 204, 0.3);
            border: 1px solid #7DA0B1;
            border-radius: 3px;
        }

        .sf-dump-public.sf-dump-highlight-active,
        .sf-dump-protected.sf-dump-highlight-active,
        .sf-dump-private.sf-dump-highlight-active,
        .sf-dump-str.sf-dump-highlight-active,
        .sf-dump-key.sf-dump-highlight-active {
            background: rgba(253, 175, 0, 0.4);
            border: 1px solid #ffa500;
            border-radius: 3px;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-hidden {
            display: none !important;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper {
            font-size: 0;
            white-space: nowrap;
            margin-bottom: 5px;
            display: flex;
            position: -webkit-sticky;
            position: sticky;
            top: 5px;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>* {
            vertical-align: top;
            box-sizing: border-box;
            height: 21px;
            font-weight: normal;
            border-radius: 0;
            background: #FFF;
            color: #757575;
            border: 1px solid #BBB;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>input.sf-dump-search-input {
            padding: 3px;
            height: 21px;
            font-size: 12px;
            border-right: none;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            color: #000;
            min-width: 15px;
            width: 100%;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>.sf-dump-search-input-next,
        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>.sf-dump-search-input-previous {
            background: #F2F2F2;
            outline: none;
            border-left: none;
            font-size: 0;
            line-height: 0;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>.sf-dump-search-input-next {
            border-top-right-radius: 3px;
            border-bottom-right-radius: 3px;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>.sf-dump-search-input-next>svg,
        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>.sf-dump-search-input-previous>svg {
            pointer-events: none;
            width: 12px;
            height: 12px;
        }

        .phpdebugbar pre.sf-dump .sf-dump-search-wrapper>.sf-dump-search-count {
            display: inline-block;
            padding: 0 5px;
            margin: 0;
            border-left: none;
            line-height: 21px;
            font-size: 12px;
        }

        .phpdebugbar pre.sf-dump,
        .phpdebugbar pre.sf-dump .sf-dump-default {
            word-wrap: break-word;
            white-space: pre-wrap;
            word-break: normal
        }

        .phpdebugbar pre.sf-dump .sf-dump-num {
            font-weight: bold;
            color: #1299DA
        }

        .phpdebugbar pre.sf-dump .sf-dump-const {
            font-weight: bold
        }

        .phpdebugbar pre.sf-dump .sf-dump-str {
            font-weight: bold;
            color: #3A9B26
        }

        .phpdebugbar pre.sf-dump .sf-dump-note {
            color: #1299DA
        }

        .phpdebugbar pre.sf-dump .sf-dump-ref {
            color: #7B7B7B
        }

        .phpdebugbar pre.sf-dump .sf-dump-public {
            color: #000000
        }

        .phpdebugbar pre.sf-dump .sf-dump-protected {
            color: #000000
        }

        .phpdebugbar pre.sf-dump .sf-dump-private {
            color: #000000
        }

        .phpdebugbar pre.sf-dump .sf-dump-meta {
            color: #B729D9
        }

        .phpdebugbar pre.sf-dump .sf-dump-key {
            color: #3A9B26
        }

        .phpdebugbar pre.sf-dump .sf-dump-index {
            color: #1299DA
        }

        .phpdebugbar pre.sf-dump .sf-dump-ellipsis {
            color: #A0A000
        }

        .phpdebugbar pre.sf-dump .sf-dump-ns {
            user-select: none;
        }

        .phpdebugbar pre.sf-dump .sf-dump-ellipsis-note {
            color: #1299DA
        }
    </style>
</head>

<body class="blue-skin">
<div id="alert-container"></div>





    <div class="clearfix"></div>
    <!-- start page content -->
    <div id="app">
       
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="scontent">
                            <form action="{{url(BaseHelper::getAdminPrefix().'/reviews/create')}}" method="POST" id="frmhomesearch">
                                {{csrf_field()}}
                                <div class="hero-search-content side-form">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <select class="form-control bg-white" name="replacement">
                                                    <option value="">أختار نوع المزايدة</option>
                                                    <option value="بيت حكومي">بيت حكومي</option>
                                                    <option value="كاش + بيت حكومي">كاش + بيت حكومي</option>
                                                    <option value="قسيمة">قسيمة</option>
                                                    <option value="كاش + قسيمة">كاش + قسيمة</option>
                                                    <option value="اسكان">اسكان</option>
                                                    <option value="كاش + اسكان">كاش + اسكان</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <select class="form-control bg-white" name="propertyName">
                                                    <option value="">أختار من قائمتك</option>
                                                    @foreach($authorProperties as $authorProperty)
                                                        <option value="{{$authorProperty->name}}">{{$authorProperty->name}}</option>
                                                        <input type="hidden" value="{{$authorProperty->id}}" name="property_id">
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <p class="position-relative">
                                                <i class="fas fa-minus minus" id="minus1"></i>
                                                <input id="qty1" type="text" value="1"
                                                       class="form-control bg-white text-center qty w-100 position-relative" />
                                                <i class="fas fa-plus add" id="add1"></i>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="px-7 ">
                                    <input type="submit" value="أضف مزايدة" class="btn btn-primary rounded-pill bg-blue row w-75 mx-auto d-block border-0 btn btn-primary"  data-bs-dismiss="modal">

                                </div>
                            </form>
                            <!-- start bottom sections -->
                            @foreach($bids as $bid)
                                <div class="col-sm-12">
                                    <div class="property-listing property-1 my-3 border shadow-none border-radius-none">
                                        <div class="listing-img-wrapper">
                                            <div class="listing-content">
                                                <div class="listing-detail-wrapper-box">
                                                    <div class="listing-detail-wrapper">
                                                        <div class="listing-short-detail">
                                                            <h4 class="blue-color listing-name mb-2">
                                                                <a class="blue-color"
                                                                   href="#"
                                                                   title="802 Madison Street Northwest">{{$bid->comment}}</a>
                                                            </h4>
                                                        </div>
                                                        <div class="list-price">
                                                            <div>
                                                                <div class="rating_wrap">
                                                                    <span class="gray-color fs-14px">{{$bid->created_at}}</span>
                                                                </div>
                                                            </div>
                                                            <h6
                                                                class="fs-14px gray-color font-weight-bold listing-card-info-price">
                                                                <i class="far fa-user"></i> {{$bid->account->first_name}} {{$bid->account->last_name}}
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        @endforeach
                        <!-- end bottom sections -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- end page content -->
    <div class="widget_shortcode">
        <div class="raw-html-embed">
            <section class="theme-bg call-to-act-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="call-to-act">
                                <div class="call-to-act-head">
                                    <h3>Want to Become a Real Estate Agent?</h3>
                                    <span>We'll help you to grow your career and growth.</span>
                                </div>
                                <a href="/register" class="btn btn-call-to-act">Sign Up Today</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    
    
    
    
    
    
    
    
    <a id="back2Top" class="top-scroll" title="Back to top" href="#"><i class="ti-arrow-up"></i></a>
</div>
<link media="all" type="text/css" rel="stylesheet"
      href="https://badal.sahla-ad.com/public/vendor/core/plugins/simple-slider/libraries/owl-carousel/owl.carousel.css?v=1.0.0">
<link media="all" type="text/css" rel="stylesheet"
      href="https://badal.sahla-ad.com/public/vendor/core/plugins/simple-slider/css/simple-slider.css?v=1.0.0">
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/bootstrap/popper.min.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/bootstrap/bootstrap.min.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/rangeslider.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/select2.min.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/jquery.magnific-popup.min.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/slick.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/slider-bg.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/lightbox.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/imagesloaded.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/plugins/lazyload.min.js"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/js/components.js?v=1.11.0"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/js/wishlist.js?v=1.11.0"></script>
<script src="https://badal.sahla-ad.com/public/themes/resido/js/app.js?v=1.11.0"></script>
<script src="https://badal.sahla-ad.com/public/vendor/core/plugins/language/js/language-public.js?v=1.0.0"></script>
<script
    src="https://badal.sahla-ad.com/public/vendor/core/plugins/simple-slider/libraries/owl-carousel/owl.carousel.js?v=1.0.0"></script>
<script
    src="https://badal.sahla-ad.com/public/vendor/core/plugins/simple-slider/js/simple-slider.js?v=1.0.0"></script>
<nav id="admin_bar">
    <div class="admin-bar-container">
        <div class="admin-bar-logo">
            <a href="https://badal.sahla-ad.com/public/admin" title="Go to dashboard">
                <img src="https://badal.sahla-ad.com/public/storage/badel-logo-04.png" alt="logo" />
            </a>
        </div>
        <ul class="admin-navbar-nav">
            <li class="admin-bar-dropdown">
                <a href="javascript:;" class="dropdown-toggle">
                    Appearance
                </a>
                <ul class="admin-bar-dropdown-menu">
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin">
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/settings/general">
                            Settings
                        </a>
                    </li>
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/theme/all">
                            Themes
                        </a>
                    </li>
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/theme/options">
                            Theme options
                        </a>
                    </li>
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/widgets">
                            Widgets
                        </a>
                    </li>
                </ul>
            </li>
            <li class="admin-bar-dropdown">
                <a href="javascript:;" class="dropdown-toggle">
                    Add new
                </a>
                <ul class="admin-bar-dropdown-menu">
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/system/users/create">
                            Users
                        </a>
                    </li>
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/pages/create">
                            Pages
                        </a>
                    </li>
                    <li>
                        <a href="https://badal.sahla-ad.com/public/admin/blog/posts/create">
                            Post
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="https://badal.sahla-ad.com/public/admin/pages/edit/35">Edit this page</a>
            </li>
        </ul>
        <ul class="admin-navbar-nav admin-navbar-nav-right">
            <li class="admin-bar-dropdown">
                <a href="https://badal.sahla-ad.com/public/admin/system/users/profile/2" class="dropdown-toggle">
                    Mohamed Shawky
                </a>
                <ul class="admin-bar-dropdown-menu">
                    <li><a href="https://badal.sahla-ad.com/public/admin/system/users/profile/2">Profile</a></li>
                    <li><a href="https://badal.sahla-ad.com/public/admin/logout">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
<script type="text/javascript">
    document.getElementsByTagName('body')[0].classList.add('show-admin-bar');
</script>
<script type="text/javascript">
    var phpdebugbar = new PhpDebugBar.DebugBar();
    phpdebugbar.addIndicator("php_version", new PhpDebugBar.DebugBar.Indicator({ "icon": "code", "tooltip": "PHP Version" }), "right");
    phpdebugbar.addTab("messages", new PhpDebugBar.DebugBar.Tab({ "icon": "list-alt", "title": "Messages", "widget": new PhpDebugBar.Widgets.MessagesWidget() }));
    phpdebugbar.addIndicator("time", new PhpDebugBar.DebugBar.Indicator({ "icon": "clock-o", "tooltip": "Request Duration" }), "right");
    phpdebugbar.addTab("timeline", new PhpDebugBar.DebugBar.Tab({ "icon": "tasks", "title": "Timeline", "widget": new PhpDebugBar.Widgets.TimelineWidget() }));
    phpdebugbar.addIndicator("memory", new PhpDebugBar.DebugBar.Indicator({ "icon": "cogs", "tooltip": "Memory Usage" }), "right");
    phpdebugbar.addTab("exceptions", new PhpDebugBar.DebugBar.Tab({ "icon": "bug", "title": "Exceptions", "widget": new PhpDebugBar.Widgets.ExceptionsWidget() }));
    phpdebugbar.addTab("views", new PhpDebugBar.DebugBar.Tab({ "icon": "leaf", "title": "Views", "widget": new PhpDebugBar.Widgets.TemplatesWidget() }));
    phpdebugbar.addTab("route", new PhpDebugBar.DebugBar.Tab({ "icon": "share", "title": "Route", "widget": new PhpDebugBar.Widgets.VariableListWidget() }));
    phpdebugbar.addIndicator("currentroute", new PhpDebugBar.DebugBar.Indicator({ "icon": "share", "tooltip": "Route" }), "right");
    phpdebugbar.addTab("queries", new PhpDebugBar.DebugBar.Tab({ "icon": "database", "title": "Queries", "widget": new PhpDebugBar.Widgets.LaravelSQLQueriesWidget() }));
    phpdebugbar.addTab("models", new PhpDebugBar.DebugBar.Tab({ "icon": "cubes", "title": "Models", "widget": new PhpDebugBar.Widgets.HtmlVariableListWidget() }));
    phpdebugbar.addTab("emails", new PhpDebugBar.DebugBar.Tab({ "icon": "inbox", "title": "Mails", "widget": new PhpDebugBar.Widgets.MailsWidget() }));
    phpdebugbar.addTab("gate", new PhpDebugBar.DebugBar.Tab({ "icon": "list-alt", "title": "Gate", "widget": new PhpDebugBar.Widgets.MessagesWidget() }));
    phpdebugbar.addTab("session", new PhpDebugBar.DebugBar.Tab({ "icon": "archive", "title": "Session", "widget": new PhpDebugBar.Widgets.VariableListWidget() }));
    phpdebugbar.addTab("request", new PhpDebugBar.DebugBar.Tab({ "icon": "tags", "title": "Request", "widget": new PhpDebugBar.Widgets.HtmlVariableListWidget() }));
    phpdebugbar.setDataMap({
        "php_version": ["php.version",],
        "messages": ["messages.messages", []],
        "messages:badge": ["messages.count", null],
        "time": ["time.duration_str", '0ms'],
        "timeline": ["time", {}],
        "memory": ["memory.peak_usage_str", '0B'],
        "exceptions": ["exceptions.exceptions", []],
        "exceptions:badge": ["exceptions.count", null],
        "views": ["views", []],
        "views:badge": ["views.nb_templates", 0],
        "route": ["route", {}],
        "currentroute": ["route.uri",],
        "queries": ["queries", []],
        "queries:badge": ["queries.nb_statements", 0],
        "models": ["models.data", {}],
        "models:badge": ["models.count", 0],
        "emails": ["swiftmailer_mails.mails", []],
        "emails:badge": ["swiftmailer_mails.count", null],
        "gate": ["gate.messages", []],
        "gate:badge": ["gate.count", null],
        "session": ["session", {}],
        "request": ["request", {}]
    });
    phpdebugbar.restoreState();
    phpdebugbar.ajaxHandler = new PhpDebugBar.AjaxHandler(phpdebugbar, undefined, true);
    phpdebugbar.ajaxHandler.bindToFetch();
    phpdebugbar.ajaxHandler.bindToXHR();
    phpdebugbar.setOpenHandler(new PhpDebugBar.OpenHandler({ "url": "https:\/\/badal.sahla-ad.com\/public\/_debugbar\/open" }));
    phpdebugbar.addDataSet({ "__meta": { "id": "X775367a88bcbd644d5a4034effbdb541", "datetime": "2022-01-27 16:09:38", "utime": 1643288978.987316, "method": "GET", "uri": "\/public\/allbids", "ip": "172.68.94.186" }, "php": { "version": "7.4.26", "interface": "litespeed" }, "messages": { "count": 0, "messages": [] }, "time": { "start": 1643288978.766699, "end": 1643288978.987346, "duration": 0.22064685821533203, "duration_str": "221ms", "measures": [{ "label": "Booting", "start": 1643288978.766699, "relative_start": 0, "end": 1643288978.856349, "relative_end": 1643288978.856349, "duration": 0.08964991569519043, "duration_str": "89.65ms", "params": [], "collector": null }, { "label": "Application", "start": 1643288978.856696, "relative_start": 0.0899968147277832, "end": 1643288978.987349, "relative_end": 3.0994415283203125e-6, "duration": 0.13065314292907715, "duration_str": "131ms", "params": [], "collector": null }] }, "memory": { "peak_usage": 11354568, "peak_usage_str": "11MB" }, "exceptions": { "count": 0, "exceptions": [] }, "views": { "nb_templates": 32, "templates": [{ "name": "theme.resido::views.page (platform\/themes\/resido\/views\/page.blade.php)", "param_count": 1, "params": ["page"], "type": "blade" }, { "name": "theme.resido::layouts.default (platform\/themes\/resido\/layouts\/default.blade.php)", "param_count": 0, "params": [], "type": "blade" }, { "name": "theme.resido::partials.header (platform\/themes\/resido\/partials\/header.blade.php)", "param_count": 0, "params": [], "type": "blade" }, { "name": "packages\/theme::partials.header (platform\/packages\/theme\/resources\/views\/partials\/header.blade.php)", "param_count": 0, "params": [], "type": "blade" }, { "name": "plugins\/language::partials.hreflang (platform\/plugins\/language\/resources\/views\/partials\/hreflang.blade.php)", "param_count": 1, "params": ["supportedLocales"], "type": "blade" }, { "name": "plugins\/language::partials.switcher (platform\/plugins\/language\/resources\/views\/partials\/switcher.blade.php)", "param_count": 1, "params": ["options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::partials.menu (platform\/themes\/resido\/partials\/menu.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "plugins\/language::partials.switcher (platform\/plugins\/language\/resources\/views\/partials\/switcher.blade.php)", "param_count": 1, "params": ["options"], "type": "blade" }, { "name": "theme.resido::partials.footer (platform\/themes\/resido\/partials\/footer.blade.php)", "param_count": 0, "params": [], "type": "blade" }, { "name": "theme.resido::\/..\/widgets\/shortcode\/templates.frontend (platform\/themes\/resido\/widgets\/shortcode\/templates\/frontend.blade.php)", "param_count": 2, "params": ["config", "sidebar"], "type": "blade" }, { "name": "theme.resido::\/..\/widgets\/custom-menu\/templates.frontend (platform\/themes\/resido\/widgets\/custom-menu\/templates\/frontend.blade.php)", "param_count": 2, "params": ["config", "sidebar"], "type": "blade" }, { "name": "packages\/menu::partials.default (platform\/packages\/menu\/resources\/views\/partials\/default.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::\/..\/widgets\/custom-menu\/templates.frontend (platform\/themes\/resido\/widgets\/custom-menu\/templates\/frontend.blade.php)", "param_count": 2, "params": ["config", "sidebar"], "type": "blade" }, { "name": "packages\/menu::partials.default (platform\/packages\/menu\/resources\/views\/partials\/default.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::\/..\/widgets\/custom-menu\/templates.frontend (platform\/themes\/resido\/widgets\/custom-menu\/templates\/frontend.blade.php)", "param_count": 2, "params": ["config", "sidebar"], "type": "blade" }, { "name": "packages\/menu::partials.default (platform\/packages\/menu\/resources\/views\/partials\/default.blade.php)", "param_count": 3, "params": ["menu", "menu_nodes", "options"], "type": "blade" }, { "name": "theme.resido::\/..\/widgets\/shortcode\/templates.frontend (platform\/themes\/resido\/widgets\/shortcode\/templates\/frontend.blade.php)", "param_count": 2, "params": ["config", "sidebar"], "type": "blade" }, { "name": "theme.resido::\/..\/widgets\/newsletter\/templates.frontend (platform\/themes\/resido\/widgets\/newsletter\/templates\/frontend.blade.php)", "param_count": 2, "params": ["config", "sidebar"], "type": "blade" }, { "name": "packages\/theme::partials.footer (platform\/packages\/theme\/resources\/views\/partials\/footer.blade.php)", "param_count": 0, "params": [], "type": "blade" }, { "name": "plugins\/cookie-consent::index (platform\/plugins\/cookie-consent\/resources\/views\/index.blade.php)", "param_count": 2, "params": ["alreadyConsentedWithCookies", "cookieConsentConfig"], "type": "blade" }, { "name": "packages\/theme::admin-bar (platform\/packages\/theme\/resources\/views\/admin-bar.blade.php)", "param_count": 0, "params": [], "type": "blade" }] }, "route": { "uri": "GET {slug?}", "middleware": "web, core, localeSessionRedirect, localizationRedirect", "as": "public.single", "controller": "Theme\\Resido\\Http\\Controllers\\ResidoController@getView", "namespace": "Theme\\Resido\\Http\\Controllers", "prefix": "", "where": [], "file": "vendor\/botble\/theme\/src\/Http\/Controllers\/PublicController.php:27-58" }, "queries": { "nb_statements": 32, "nb_failed_statements": 0, "accumulated_duration": 0.015730000000000008, "accumulated_duration_str": "15.73ms", "statements": [{ "sql": "select * from `slugs` where `key` = 'allbids' and `prefix` = '' limit 1", "type": "query", "params": [], "bindings": ["allbids", ""], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/vendor\/botble\/slug\/src\/SlugHelper.php", "line": 136 }, { "index": 20, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/theme\/src\/Http\/Controllers\/PublicController.php", "line": 33 }], "duration": 0.0008399999999999999, "duration_str": "840\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 0, "width_percent": 5.34 }, { "sql": "select * from `users` where `id` = 2 limit 1", "type": "query", "params": [], "bindings": ["2"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/EloquentUserProvider.php", "line": 52 }, { "index": 16, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/SessionGuard.php", "line": 141 }, { "index": 17, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/GuardHelpers.php", "line": 60 }, { "index": 18, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/AuthManager.php", "line": 332 }, { "index": 19, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }], "duration": 0.00037, "duration_str": "370\u03bcs", "stmt_id": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/EloquentUserProvider.php:52", "connection": "biddings", "start_percent": 5.34, "width_percent": 2.352 }, { "sql": "select * from `pages` where `id` = '35' and `status` = 'published' limit 1", "type": "query", "params": [], "bindings": ["35", "published"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 623 }, { "index": 18, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 19, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 88 }, { "index": 22, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }], "duration": 0.00034, "duration_str": "340\u03bcs", "stmt_id": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php:623", "connection": "biddings", "start_percent": 7.692, "width_percent": 2.161 }, { "sql": "select * from `slugs` where `slugs`.`reference_id` in (35) and `slugs`.`reference_type` = 'Botble\\Page\\Models\\Page'", "type": "query", "params": [], "bindings": ["Botble\\Page\\Models\\Page"], "hints": null, "show_copy": false, "backtrace": [{ "index": 20, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 623 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 24, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }, { "index": 26, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 88 }, { "index": 27, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }], "duration": 0.0007, "duration_str": "700\u03bcs", "stmt_id": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php:623", "connection": "biddings", "start_percent": 9.854, "width_percent": 4.45 }, { "sql": "select * from `language_meta` where `reference_type` = 'Botble\\Page\\Models\\Page' and `reference_id` = 35 limit 1", "type": "query", "params": [], "bindings": ["Botble\\Page\\Models\\Page", "35"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 628 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 23, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }], "duration": 0.0004, "duration_str": "400\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 14.304, "width_percent": 2.543 }, { "sql": "select * from `pages` where `id` = '35' and `status` = 'published' limit 1", "type": "query", "params": [], "bindings": ["35", "published"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/vendor\/botble\/page\/src\/Services\/PageService.php", "line": 42 }, { "index": 20, "namespace": null, "name": "\/vendor\/botble\/page\/src\/Providers\/HookServiceProvider.php", "line": 107 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }], "duration": 0.00033, "duration_str": "330\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 16.847, "width_percent": 2.098 }, { "sql": "select * from `slugs` where `slugs`.`reference_id` in (35) and `slugs`.`reference_type` = 'Botble\\Page\\Models\\Page'", "type": "query", "params": [], "bindings": ["Botble\\Page\\Models\\Page"], "hints": null, "show_copy": false, "backtrace": [{ "index": 20, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 23, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 24, "namespace": null, "name": "\/vendor\/botble\/page\/src\/Services\/PageService.php", "line": 42 }, { "index": 25, "namespace": null, "name": "\/vendor\/botble\/page\/src\/Providers\/HookServiceProvider.php", "line": 107 }, { "index": 28, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }], "duration": 0.00069, "duration_str": "690\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 18.945, "width_percent": 4.387 }, { "sql": "select `reference_id`, `reference_type`, `meta_key`, `meta_value` from `meta_boxes` where `meta_boxes`.`reference_id` in (35) and `meta_boxes`.`reference_type` = 'Botble\\Page\\Models\\Page'", "type": "query", "params": [], "bindings": ["Botble\\Page\\Models\\Page"], "hints": null, "show_copy": false, "backtrace": [{ "index": 22, "namespace": null, "name": "\/vendor\/botble\/seo-helper\/src\/Providers\/HookServiceProvider.php", "line": 79 }, { "index": 25, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 26, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 56 }, { "index": 28, "namespace": null, "name": "\/vendor\/botble\/page\/src\/Providers\/HookServiceProvider.php", "line": 107 }, { "index": 31, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }], "duration": 0.00043, "duration_str": "430\u03bcs", "stmt_id": "\/vendor\/botble\/seo-helper\/src\/Providers\/HookServiceProvider.php:79", "connection": "biddings", "start_percent": 23.331, "width_percent": 2.734 }, { "sql": "select * from `re_currencies` order by `order` asc", "type": "query", "params": [], "bindings": [], "hints": null, "show_copy": false, "backtrace": [{ "index": 14, "namespace": null, "name": "\/platform\/plugins\/real-estate\/src\/Repositories\/Eloquent\/CurrencyRepository.php", "line": 17 }, { "index": 17, "namespace": null, "name": "\/platform\/plugins\/real-estate\/src\/Repositories\/Caches\/CurrencyCacheDecorator.php", "line": 15 }, { "index": 18, "namespace": null, "name": "\/platform\/plugins\/real-estate\/src\/Supports\/CurrencySupport.php", "line": 116 }, { "index": 19, "namespace": null, "name": "\/platform\/plugins\/real-estate\/helpers\/currencies.php", "line": 149 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }], "duration": 0.00043, "duration_str": "430\u03bcs", "stmt_id": "\/platform\/plugins\/real-estate\/src\/Repositories\/Eloquent\/CurrencyRepository.php:17", "connection": "biddings", "start_percent": 26.065, "width_percent": 2.734 }, { "sql": "select * from `menus` inner join `language_meta` on `language_meta`.`reference_id` = `menus`.`id` where `status` = 'published' and `language_meta`.`reference_type` = 'Botble\\Menu\\Models\\Menu' and `language_meta`.`lang_meta_code` = 'en_US'", "type": "query", "params": [], "bindings": ["published", "Botble\\Menu\\Models\\Menu", "en_US"], "hints": null, "show_copy": false, "backtrace": [{ "index": 14, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 159 }, { "index": 17, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 192 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 249 }, { "index": 19, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 239 }, { "index": 20, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 215 }], "duration": 0.0011, "duration_str": "1.1ms", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:159", "connection": "biddings", "start_percent": 28.798, "width_percent": 6.993 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`menu_id` in (1, 2, 3, 4, 12, 13, 14, 15)", "type": "query", "params": [], "bindings": [], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 159 }, { "index": 22, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 192 }, { "index": 23, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 249 }, { "index": 24, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 239 }, { "index": 25, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 215 }], "duration": 0.00078, "duration_str": "780\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:159", "connection": "biddings", "start_percent": 35.791, "width_percent": 4.959 }, { "sql": "select * from `menu_locations` where `menu_locations`.`menu_id` in (1, 2, 3, 4, 12, 13, 14, 15)", "type": "query", "params": [], "bindings": [], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 159 }, { "index": 22, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 192 }, { "index": 23, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 249 }, { "index": 24, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 239 }, { "index": 25, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Menu.php", "line": 215 }], "duration": 0.00032, "duration_str": "320\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:159", "connection": "biddings", "start_percent": 40.75, "width_percent": 2.034 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 1 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["1"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00069, "duration_str": "690\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 42.784, "width_percent": 4.387 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 12 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["12"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00061, "duration_str": "610\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 47.171, "width_percent": 3.878 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 13 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["13"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00041999999999999996, "duration_str": "420\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 51.049, "width_percent": 2.67 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 17 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["17"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00045, "duration_str": "450\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 53.719, "width_percent": 2.861 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 22 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["22"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00049, "duration_str": "490\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 56.58, "width_percent": 3.115 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 23 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["23"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00043, "duration_str": "430\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 59.695, "width_percent": 2.734 }, { "sql": "select * from `re_properties` where `re_properties`.`id` = '1' limit 1", "type": "query", "params": [], "bindings": ["1"], "hints": null, "show_copy": false, "backtrace": [{ "index": 20, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Models\/MenuNode.php", "line": 74 }, { "index": 27, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 28, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Models\/MenuNode.php", "line": 111 }, { "index": 34, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }], "duration": 0.00046, "duration_str": "460\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 62.428, "width_percent": 2.924 }, { "sql": "select * from `re_properties` where `re_properties`.`id` = '2' limit 1", "type": "query", "params": [], "bindings": ["2"], "hints": null, "show_copy": false, "backtrace": [{ "index": 20, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Models\/MenuNode.php", "line": 74 }, { "index": 27, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 28, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Models\/MenuNode.php", "line": 111 }, { "index": 34, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }], "duration": 0.00037, "duration_str": "370\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 65.353, "width_percent": 2.352 }, { "sql": "select * from `re_properties` where `re_properties`.`id` = '3' limit 1", "type": "query", "params": [], "bindings": ["3"], "hints": null, "show_copy": false, "backtrace": [{ "index": 20, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Models\/MenuNode.php", "line": 74 }, { "index": 27, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 28, "namespace": null, "name": "\/vendor\/botble\/menu\/src\/Models\/MenuNode.php", "line": 111 }, { "index": 34, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }], "duration": 0.00035, "duration_str": "350\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 67.705, "width_percent": 2.225 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 27 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["27"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00049, "duration_str": "490\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 69.93, "width_percent": 3.115 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 30 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["30"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00079, "duration_str": "790\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 73.045, "width_percent": 5.022 }, { "sql": "select * from `menu_nodes` where `menu_nodes`.`parent_id` = 37 and `menu_nodes`.`parent_id` is not null order by `position` asc", "type": "query", "params": [], "bindings": ["37"], "hints": null, "show_copy": false, "backtrace": [{ "index": 19, "namespace": null, "name": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php", "line": 26 }, { "index": 20, "namespace": "view", "name": "theme.resido::partials.menu", "line": 11 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }, { "index": 23, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/PhpEngine.php", "line": 58 }, { "index": 24, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Engines\/CompilerEngine.php", "line": 61 }], "duration": 0.00057, "duration_str": "570\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/base\/src\/Models\/BaseModel.php:26", "connection": "biddings", "start_percent": 78.067, "width_percent": 3.624 }, { "sql": "select * from `re_accounts` where `id` = 17 limit 1", "type": "query", "params": [], "bindings": ["17"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/EloquentUserProvider.php", "line": 52 }, { "index": 16, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/SessionGuard.php", "line": 141 }, { "index": 17, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/GuardHelpers.php", "line": 60 }, { "index": 18, "namespace": "view", "name": "theme.resido::partials.header", "line": 123 }, { "index": 20, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Filesystem\/Filesystem.php", "line": 108 }], "duration": 0.00039, "duration_str": "390\u03bcs", "stmt_id": "\/vendor\/laravel\/framework\/src\/Illuminate\/Auth\/EloquentUserProvider.php:52", "connection": "biddings", "start_percent": 81.691, "width_percent": 2.479 }, { "sql": "select * from `widgets` where `theme` = 'resido'", "type": "query", "params": [], "bindings": ["resido"], "hints": null, "show_copy": false, "backtrace": [{ "index": 14, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 159 }, { "index": 17, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 192 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/widget\/src\/WidgetGroupCollection.php", "line": 146 }, { "index": 19, "namespace": null, "name": "\/vendor\/botble\/widget\/src\/WidgetGroupCollection.php", "line": 130 }, { "index": 20, "namespace": null, "name": "\/vendor\/botble\/widget\/src\/WidgetGroupCollection.php", "line": 111 }], "duration": 0.00037, "duration_str": "370\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:159", "connection": "biddings", "start_percent": 84.17, "width_percent": 2.352 }, { "sql": "select * from `blocks` where `alias` = 'sign-up' and `status` = 'published' limit 1", "type": "query", "params": [], "bindings": ["sign-up", "published"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 623 }, { "index": 18, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 19, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 88 }, { "index": 22, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }], "duration": 0.00047, "duration_str": "470\u03bcs", "stmt_id": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php:623", "connection": "biddings", "start_percent": 86.523, "width_percent": 2.988 }, { "sql": "select * from `language_meta` where `reference_type` = 'Botble\\Block\\Models\\Block' and `reference_id` = 1 limit 1", "type": "query", "params": [], "bindings": ["Botble\\Block\\Models\\Block", "1"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 628 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 23, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }], "duration": 0.00037, "duration_str": "370\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 89.51, "width_percent": 2.352 }, { "sql": "select * from `blocks` where `alias` = 'sign-up' and `status` = 'published' limit 1", "type": "query", "params": [], "bindings": ["sign-up", "published"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/platform\/plugins\/block\/src\/Providers\/HookServiceProvider.php", "line": 36 }, { "index": 24, "namespace": null, "name": "\/vendor\/botble\/shortcode\/src\/Compilers\/ShortcodeCompiler.php", "line": 128 }, { "index": 25, "namespace": null, "name": "\/vendor\/botble\/shortcode\/src\/Compilers\/ShortcodeCompiler.php", "line": 92 }], "duration": 0.00029, "duration_str": "290\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 91.863, "width_percent": 1.844 }, { "sql": "select * from `blocks` where `alias` = 'download-app-footer' and `status` = 'published' limit 1", "type": "query", "params": [], "bindings": ["download-app-footer", "published"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 623 }, { "index": 18, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 19, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }, { "index": 21, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 88 }, { "index": 22, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }], "duration": 0.00037, "duration_str": "370\u03bcs", "stmt_id": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php:623", "connection": "biddings", "start_percent": 93.706, "width_percent": 2.352 }, { "sql": "select * from `language_meta` where `reference_type` = 'Botble\\Block\\Models\\Block' and `reference_id` = 3 limit 1", "type": "query", "params": [], "bindings": ["Botble\\Block\\Models\\Block", "3"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/platform\/plugins\/language\/src\/Providers\/LanguageServiceProvider.php", "line": 628 }, { "index": 22, "namespace": null, "name": "\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php", "line": 261 }, { "index": 23, "namespace": null, "name": "\/platform\/core\/base\/helpers\/action-filter.php", "line": 48 }], "duration": 0.00032, "duration_str": "320\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 96.058, "width_percent": 2.034 }, { "sql": "select * from `blocks` where `alias` = 'download-app-footer' and `status` = 'published' limit 1", "type": "query", "params": [], "bindings": ["download-app-footer", "published"], "hints": null, "show_copy": false, "backtrace": [{ "index": 15, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php", "line": 262 }, { "index": 18, "namespace": null, "name": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Caches\/CacheAbstractDecorator.php", "line": 168 }, { "index": 19, "namespace": null, "name": "\/platform\/plugins\/block\/src\/Providers\/HookServiceProvider.php", "line": 36 }, { "index": 24, "namespace": null, "name": "\/vendor\/botble\/shortcode\/src\/Compilers\/ShortcodeCompiler.php", "line": 128 }, { "index": 25, "namespace": null, "name": "\/vendor\/botble\/shortcode\/src\/Compilers\/ShortcodeCompiler.php", "line": 92 }], "duration": 0.0003, "duration_str": "300\u03bcs", "stmt_id": "\/vendor\/botble\/platform\/support\/src\/Repositories\/Eloquent\/RepositoriesAbstract.php:262", "connection": "biddings", "start_percent": 98.093, "width_percent": 1.907 }] }, "models": { "data": { "Botble\\Block\\Models\\Block": 4, "Botble\\Widget\\Models\\Widget": 9, "Botble\\RealEstate\\Models\\Account": 1, "Botble\\Menu\\Models\\MenuLocation": 4, "Botble\\Menu\\Models\\MenuNode": 95, "Botble\\Menu\\Models\\Menu": 8, "Botble\\RealEstate\\Models\\Currency": 1, "Botble\\Language\\Models\\LanguageMeta": 3, "Botble\\Page\\Models\\Page": 2, "Botble\\ACL\\Models\\User": 1, "Botble\\Slug\\Models\\Slug": 3 }, "count": 131 }, "swiftmailer_mails": { "count": 0, "mails": [] }, "gate": { "count": 0, "messages": [] }, "session": { "url": "[]", "_token": "HtnhadFgNS5BmPCwPrhFch454mVvPfZbD2QDyaRA", "language": "en", "_previous": "array:1 [\n  \"url\" => \"https:\/\/badal.sahla-ad.com\/public\/allbids\"\n]", "_flash": "array:2 [\n  \"old\" => []\n  \"new\" => []\n]", "login_account_59ba36addc2b2f9401580f014c7f58ea4e30989d": "17", "admin-theme": "default", "login_web_59ba36addc2b2f9401580f014c7f58ea4e30989d": "2", "PHPDEBUGBAR_STACK_DATA": "[]" }, "request": { "path_info": "\/allbids", "status_code": "<pre class=sf-dump id=sf-dump-1400547550 data-indent-pad=\"  \"><span class=sf-dump-num>200<\/span>\n<\/pre><script>Sfdump(\"sf-dump-1400547550\", {\"maxDepth\":0})<\/script>\n", "status_text": "OK", "format": "html", "content_type": "text\/html; charset=UTF-8", "request_query": "<pre class=sf-dump id=sf-dump-2025228839 data-indent-pad=\"  \">[]\n<\/pre><script>Sfdump(\"sf-dump-2025228839\", {\"maxDepth\":0})<\/script>\n", "request_request": "<pre class=sf-dump id=sf-dump-217028762 data-indent-pad=\"  \">[]\n<\/pre><script>Sfdump(\"sf-dump-217028762\", {\"maxDepth\":0})<\/script>\n", "request_headers": "<pre class=sf-dump id=sf-dump-1138175968 data-indent-pad=\"  \"><span class=sf-dump-note>array:23<\/span> [<samp data-depth=1 class=sf-dump-expanded>\n  \"<span class=sf-dump-key>accept<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"135 characters\">text\/html,application\/xhtml+xml,application\/xml;q=0.9,image\/avif,image\/webp,image\/apng,*\/*;q=0.8,application\/signed-exchange;v=b3;q=0.9<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>accept-encoding<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"4 characters\">gzip<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>accept-language<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"32 characters\">en-US,en;q=0.9,ar;q=0.8,la;q=0.7<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>content-length<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str>0<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cookie<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"1924 characters\">_tccl_visitor=26557a9f-8629-4aea-97a2-042a25742f08; _tccl_visit=2657c1c8-8499-44f0-8a08-0ed088a91a93; remember_account_59ba36addc2b2f9401580f014c7f58ea4e30989d=eyJpdiI6InFMaENCdEIvTHB1WnV2ejUxRkNzN3c9PSIsInZhbHVlIjoiYlM4d3JYSzVaQ3NCZDlXVGFDdzN6aHdJODQ5N1ZEcmZROUtLV3RSdk1FdUowck5rck5YS0ROM1BFTXp2eTVsekYya3dOTmtaeG5JaUVyQTdhVStjQlo3cEdFY1hwNmk2TXh3OFZ1SjZzUk1YNDJpdE1HQlBXM2UzbVdncjNSZXQ4ZHZ1NC95MEFteTRLcUt6VEc1eE1tTytzZlRyaG5NeVh2T3hMejZZd2FiMTgwOU1CSjAyNEtYN1ZqbW1BU2ZTc0tHcmZsanF0VHVZUmMxbXVOcWdyYkx3Nm1zOFF1NTNadklsQnJMOEhUYz0iLCJtYWMiOiJhNTE3NGVjYTc0MzJhYzM1YTQ2N2QzODk2MmYxYWY3MDQyNGM2ZDdlMjdmOWYxOWEyZTE0MDFkNGRlODgxNTY1IiwidGFnIjoiIn0%3D; cookie_for_consent=1; remember_web_59ba36addc2b2f9401580f014c7f58ea4e30989d=eyJpdiI6InA3TlJaSkVWZGhwWFNWbmhxdjhUdkE9PSIsInZhbHVlIjoiNUxQYjJGTHZHSlczczJUeWJhaVVMMXhBWit3aGFsZitUTjYvbFZnWlE0SkR6aTRFWjhXajdGRXhtbk5ZdHFmWmEzdkdoUVo0SUJndHlZVS85RmNGRytZWFM5NmpJQ1kxbi9lYmF6SHZUOTByTGIyM2lzQnljMWFESjVHbWRIMk9ja3V4Z1VMMkQ3eTJFWG9mRmUxbjYzODMwQXJ4YWZZQ2toKzdzR0cxY05McTdaTkdXWXNmOCtZaUVObHNTYTVBNEdIZFR3eVBwZVRLM0oxZVM5U1pZZDNVT2xXbEJrbituQ0Q1eWZXOVVUaz0iLCJtYWMiOiJjNThiMWFjNDA2NzdiMzkxMGY3NTA4ZTk5NTZlNGY5ZThkN2ZhNzRhNWEzZGMwNDZlMDVmOTZjZTVlZDEzZGFkIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlpocmRSRWRJdWxYK1Vqc2tBWU1YN2c9PSIsInZhbHVlIjoiSFNaOWx2VEdZeDQzaDh5dXViakZuOXF2Wm9mM08wQ0xBVldueGtTZ1dKTmRNNGU1bDROZ0xMd1RlN1M1NFkvUnhVblFCYm9jNnR4dm5TWjZIc3pNUE0rKzR0aG5oaUFaNFdDV3VlaTI5eTYyaW9va1dONjRaN2FVaHkwY2ZMdDMiLCJtYWMiOiJmNTFjOTFkYWEzZmJiMDU5NTIyZmY0ZjkwY2UwMzA2NzgwYTFkOTIzYmEwYjBhYjRlZDJjMzM1Y2I4Yjk1NDdiIiwidGFnIjoiIn0%3D; botble_session=eyJpdiI6ImY4V1UwMlJrQ05JUXdOeTZROUZzOFE9PSIsInZhbHVlIjoidlNBTFlGeTVmYzBlU2FSS01sK0xXMjdteWdpSHlOLzNTL2dlQTRxYzhFVnQxTWVmNXFVM1VpQTB0TzZ1U252dGR4d0srY0hnL3BWK3g0cUhCc3UxS2Jpa081bnZmNFJMdEloUWUzNDQyaDNrOGc3K1IvWHdIZ2VVNHh5VmZ1L1AiLCJtYWMiOiI5MTI3YjI4NzVlOTVkYzAzOTgwZWE5MmQwZmNkZDc4YzkxMGY3NDY0MjdmYWJhNDExZjk0NjFiY2U1OTEwYTQzIiwidGFnIjoiIn0%3D<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>host<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"18 characters\">badal.sahla-ad.com<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>referer<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"34 characters\">https:\/\/badal.sahla-ad.com\/public\/<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>user-agent<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"104 characters\">Mozilla\/5.0 (X11; Linux x86_64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/97.0.4692.99 Safari\/537.36<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>x-forwarded-for<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"13 characters\">41.69.102.136<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cdn-loop<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"10 characters\">cloudflare<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cf-connecting-ip<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"13 characters\">41.69.102.136<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cf-ipcountry<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"2 characters\">EG<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cf-ray<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"20 characters\">6d42377509f811b7-BCN<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>x-forwarded-proto<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"5 characters\">https<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cf-visitor<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"18 characters\">{&quot;scheme&quot;:&quot;https&quot;}<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-ch-ua<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"64 characters\">&quot; Not;A Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;97&quot;, &quot;Chromium&quot;;v=&quot;97&quot;<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-ch-ua-mobile<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"2 characters\">?0<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-ch-ua-platform<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"7 characters\">&quot;Linux&quot;<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>upgrade-insecure-requests<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str>1<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-fetch-site<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"11 characters\">same-origin<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-fetch-mode<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"8 characters\">navigate<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-fetch-user<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"2 characters\">?1<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>sec-fetch-dest<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"8 characters\">document<\/span>\"\n  <\/samp>]\n<\/samp>]\n<\/pre><script>Sfdump(\"sf-dump-1138175968\", {\"maxDepth\":0})<\/script>\n", "request_server": "<pre class=sf-dump id=sf-dump-1784825390 data-indent-pad=\"  \"><span class=sf-dump-note>array:76<\/span> [<samp data-depth=1 class=sf-dump-expanded>\n  \"<span class=sf-dump-key>LSPHP_ENABLE_USER_INI<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">on<\/span>\"\n  \"<span class=sf-dump-key>PATH<\/span>\" => \"<span class=sf-dump-str title=\"28 characters\">\/usr\/local\/bin:\/usr\/bin:\/bin<\/span>\"\n  \"<span class=sf-dump-key>TEMP<\/span>\" => \"<span class=sf-dump-str title=\"4 characters\">\/tmp<\/span>\"\n  \"<span class=sf-dump-key>TMP<\/span>\" => \"<span class=sf-dump-str title=\"4 characters\">\/tmp<\/span>\"\n  \"<span class=sf-dump-key>TMPDIR<\/span>\" => \"<span class=sf-dump-str title=\"4 characters\">\/tmp<\/span>\"\n  \"<span class=sf-dump-key>PWD<\/span>\" => \"<span class=sf-dump-str>\/<\/span>\"\n  \"<span class=sf-dump-key>HTTP_ACCEPT<\/span>\" => \"<span class=sf-dump-str title=\"135 characters\">text\/html,application\/xhtml+xml,application\/xml;q=0.9,image\/avif,image\/webp,image\/apng,*\/*;q=0.8,application\/signed-exchange;v=b3;q=0.9<\/span>\"\n  \"<span class=sf-dump-key>HTTP_ACCEPT_ENCODING<\/span>\" => \"<span class=sf-dump-str title=\"4 characters\">gzip<\/span>\"\n  \"<span class=sf-dump-key>HTTP_ACCEPT_LANGUAGE<\/span>\" => \"<span class=sf-dump-str title=\"32 characters\">en-US,en;q=0.9,ar;q=0.8,la;q=0.7<\/span>\"\n  \"<span class=sf-dump-key>CONTENT_LENGTH<\/span>\" => \"<span class=sf-dump-str>0<\/span>\"\n  \"<span class=sf-dump-key>HTTP_COOKIE<\/span>\" => \"<span class=sf-dump-str title=\"1924 characters\">_tccl_visitor=26557a9f-8629-4aea-97a2-042a25742f08; _tccl_visit=2657c1c8-8499-44f0-8a08-0ed088a91a93; remember_account_59ba36addc2b2f9401580f014c7f58ea4e30989d=eyJpdiI6InFMaENCdEIvTHB1WnV2ejUxRkNzN3c9PSIsInZhbHVlIjoiYlM4d3JYSzVaQ3NCZDlXVGFDdzN6aHdJODQ5N1ZEcmZROUtLV3RSdk1FdUowck5rck5YS0ROM1BFTXp2eTVsekYya3dOTmtaeG5JaUVyQTdhVStjQlo3cEdFY1hwNmk2TXh3OFZ1SjZzUk1YNDJpdE1HQlBXM2UzbVdncjNSZXQ4ZHZ1NC95MEFteTRLcUt6VEc1eE1tTytzZlRyaG5NeVh2T3hMejZZd2FiMTgwOU1CSjAyNEtYN1ZqbW1BU2ZTc0tHcmZsanF0VHVZUmMxbXVOcWdyYkx3Nm1zOFF1NTNadklsQnJMOEhUYz0iLCJtYWMiOiJhNTE3NGVjYTc0MzJhYzM1YTQ2N2QzODk2MmYxYWY3MDQyNGM2ZDdlMjdmOWYxOWEyZTE0MDFkNGRlODgxNTY1IiwidGFnIjoiIn0%3D; cookie_for_consent=1; remember_web_59ba36addc2b2f9401580f014c7f58ea4e30989d=eyJpdiI6InA3TlJaSkVWZGhwWFNWbmhxdjhUdkE9PSIsInZhbHVlIjoiNUxQYjJGTHZHSlczczJUeWJhaVVMMXhBWit3aGFsZitUTjYvbFZnWlE0SkR6aTRFWjhXajdGRXhtbk5ZdHFmWmEzdkdoUVo0SUJndHlZVS85RmNGRytZWFM5NmpJQ1kxbi9lYmF6SHZUOTByTGIyM2lzQnljMWFESjVHbWRIMk9ja3V4Z1VMMkQ3eTJFWG9mRmUxbjYzODMwQXJ4YWZZQ2toKzdzR0cxY05McTdaTkdXWXNmOCtZaUVObHNTYTVBNEdIZFR3eVBwZVRLM0oxZVM5U1pZZDNVT2xXbEJrbituQ0Q1eWZXOVVUaz0iLCJtYWMiOiJjNThiMWFjNDA2NzdiMzkxMGY3NTA4ZTk5NTZlNGY5ZThkN2ZhNzRhNWEzZGMwNDZlMDVmOTZjZTVlZDEzZGFkIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlpocmRSRWRJdWxYK1Vqc2tBWU1YN2c9PSIsInZhbHVlIjoiSFNaOWx2VEdZeDQzaDh5dXViakZuOXF2Wm9mM08wQ0xBVldueGtTZ1dKTmRNNGU1bDROZ0xMd1RlN1M1NFkvUnhVblFCYm9jNnR4dm5TWjZIc3pNUE0rKzR0aG5oaUFaNFdDV3VlaTI5eTYyaW9va1dONjRaN2FVaHkwY2ZMdDMiLCJtYWMiOiJmNTFjOTFkYWEzZmJiMDU5NTIyZmY0ZjkwY2UwMzA2NzgwYTFkOTIzYmEwYjBhYjRlZDJjMzM1Y2I4Yjk1NDdiIiwidGFnIjoiIn0%3D; botble_session=eyJpdiI6ImY4V1UwMlJrQ05JUXdOeTZROUZzOFE9PSIsInZhbHVlIjoidlNBTFlGeTVmYzBlU2FSS01sK0xXMjdteWdpSHlOLzNTL2dlQTRxYzhFVnQxTWVmNXFVM1VpQTB0TzZ1U252dGR4d0srY0hnL3BWK3g0cUhCc3UxS2Jpa081bnZmNFJMdEloUWUzNDQyaDNrOGc3K1IvWHdIZ2VVNHh5VmZ1L1AiLCJtYWMiOiI5MTI3YjI4NzVlOTVkYzAzOTgwZWE5MmQwZmNkZDc4YzkxMGY3NDY0MjdmYWJhNDExZjk0NjFiY2U1OTEwYTQzIiwidGFnIjoiIn0%3D<\/span>\"\n  \"<span class=sf-dump-key>HTTP_HOST<\/span>\" => \"<span class=sf-dump-str title=\"18 characters\">badal.sahla-ad.com<\/span>\"\n  \"<span class=sf-dump-key>HTTP_REFERER<\/span>\" => \"<span class=sf-dump-str title=\"34 characters\">https:\/\/badal.sahla-ad.com\/public\/<\/span>\"\n  \"<span class=sf-dump-key>HTTP_USER_AGENT<\/span>\" => \"<span class=sf-dump-str title=\"104 characters\">Mozilla\/5.0 (X11; Linux x86_64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/97.0.4692.99 Safari\/537.36<\/span>\"\n  \"<span class=sf-dump-key>HTTP_X_FORWARDED_FOR<\/span>\" => \"<span class=sf-dump-str title=\"13 characters\">41.69.102.136<\/span>\"\n  \"<span class=sf-dump-key>HTTP_CDN_LOOP<\/span>\" => \"<span class=sf-dump-str title=\"10 characters\">cloudflare<\/span>\"\n  \"<span class=sf-dump-key>HTTP_CF_CONNECTING_IP<\/span>\" => \"<span class=sf-dump-str title=\"13 characters\">41.69.102.136<\/span>\"\n  \"<span class=sf-dump-key>HTTP_CF_IPCOUNTRY<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">EG<\/span>\"\n  \"<span class=sf-dump-key>HTTP_CF_RAY<\/span>\" => \"<span class=sf-dump-str title=\"20 characters\">6d42377509f811b7-BCN<\/span>\"\n  \"<span class=sf-dump-key>HTTP_X_FORWARDED_PROTO<\/span>\" => \"<span class=sf-dump-str title=\"5 characters\">https<\/span>\"\n  \"<span class=sf-dump-key>HTTP_CF_VISITOR<\/span>\" => \"<span class=sf-dump-str title=\"18 characters\">{&quot;scheme&quot;:&quot;https&quot;}<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_CH_UA<\/span>\" => \"<span class=sf-dump-str title=\"64 characters\">&quot; Not;A Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;97&quot;, &quot;Chromium&quot;;v=&quot;97&quot;<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_CH_UA_MOBILE<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">?0<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_CH_UA_PLATFORM<\/span>\" => \"<span class=sf-dump-str title=\"7 characters\">&quot;Linux&quot;<\/span>\"\n  \"<span class=sf-dump-key>HTTP_UPGRADE_INSECURE_REQUESTS<\/span>\" => \"<span class=sf-dump-str>1<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_FETCH_SITE<\/span>\" => \"<span class=sf-dump-str title=\"11 characters\">same-origin<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_FETCH_MODE<\/span>\" => \"<span class=sf-dump-str title=\"8 characters\">navigate<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_FETCH_USER<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">?1<\/span>\"\n  \"<span class=sf-dump-key>HTTP_SEC_FETCH_DEST<\/span>\" => \"<span class=sf-dump-str title=\"8 characters\">document<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_UNIQUE_ID<\/span>\" => \"<span class=sf-dump-str title=\"27 characters\">YfKZkthU4JQ7rQJALHzuIAAAzyI<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_SCRIPT_URL<\/span>\" => \"<span class=sf-dump-str title=\"15 characters\">\/public\/allbids<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_SCRIPT_URI<\/span>\" => \"<span class=sf-dump-str title=\"41 characters\">https:\/\/badal.sahla-ad.com\/public\/allbids<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_HTTPS<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">on<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_SSL_TLS_SNI<\/span>\" => \"<span class=sf-dump-str title=\"18 characters\">badal.sahla-ad.com<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_HTTP2<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">on<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_H2PUSH<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">off<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_H2_PUSH<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">off<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_H2_PUSHED<\/span>\" => \"\"\n  \"<span class=sf-dump-key>REDIRECT_H2_PUSHED_ON<\/span>\" => \"\"\n  \"<span class=sf-dump-key>REDIRECT_H2_STREAM_ID<\/span>\" => \"<span class=sf-dump-str>7<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_H2_STREAM_TAG<\/span>\" => \"<span class=sf-dump-str title=\"5 characters\">224-7<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_STATUS<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">200<\/span>\"\n  \"<span class=sf-dump-key>UNIQUE_ID<\/span>\" => \"<span class=sf-dump-str title=\"27 characters\">YfKZkthU4JQ7rQJALHzuIAAAzyI<\/span>\"\n  \"<span class=sf-dump-key>SCRIPT_URL<\/span>\" => \"<span class=sf-dump-str title=\"15 characters\">\/public\/allbids<\/span>\"\n  \"<span class=sf-dump-key>SCRIPT_URI<\/span>\" => \"<span class=sf-dump-str title=\"41 characters\">https:\/\/badal.sahla-ad.com\/public\/allbids<\/span>\"\n  \"<span class=sf-dump-key>HTTPS<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">on<\/span>\"\n  \"<span class=sf-dump-key>SSL_TLS_SNI<\/span>\" => \"<span class=sf-dump-str title=\"18 characters\">badal.sahla-ad.com<\/span>\"\n  \"<span class=sf-dump-key>HTTP2<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">on<\/span>\"\n  \"<span class=sf-dump-key>H2PUSH<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">off<\/span>\"\n  \"<span class=sf-dump-key>H2_PUSH<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">off<\/span>\"\n  \"<span class=sf-dump-key>H2_PUSHED<\/span>\" => \"\"\n  \"<span class=sf-dump-key>H2_PUSHED_ON<\/span>\" => \"\"\n  \"<span class=sf-dump-key>H2_STREAM_ID<\/span>\" => \"<span class=sf-dump-str>7<\/span>\"\n  \"<span class=sf-dump-key>H2_STREAM_TAG<\/span>\" => \"<span class=sf-dump-str title=\"5 characters\">224-7<\/span>\"\n  \"<span class=sf-dump-key>SERVER_SIGNATURE<\/span>\" => \"\"\n  \"<span class=sf-dump-key>SERVER_SOFTWARE<\/span>\" => \"<span class=sf-dump-str title=\"6 characters\">Apache<\/span>\"\n  \"<span class=sf-dump-key>SERVER_NAME<\/span>\" => \"<span class=sf-dump-str title=\"18 characters\">badal.sahla-ad.com<\/span>\"\n  \"<span class=sf-dump-key>SERVER_ADDR<\/span>\" => \"<span class=sf-dump-str title=\"13 characters\">107.180.0.110<\/span>\"\n  \"<span class=sf-dump-key>SERVER_PORT<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">443<\/span>\"\n  \"<span class=sf-dump-key>REMOTE_ADDR<\/span>\" => \"<span class=sf-dump-str title=\"13 characters\">172.68.94.186<\/span>\"\n  \"<span class=sf-dump-key>DOCUMENT_ROOT<\/span>\" => \"<span class=sf-dump-str title=\"24 characters\">\/home\/gs4bgu9db872\/badal<\/span>\"\n  \"<span class=sf-dump-key>REQUEST_SCHEME<\/span>\" => \"<span class=sf-dump-str title=\"5 characters\">https<\/span>\"\n  \"<span class=sf-dump-key>CONTEXT_PREFIX<\/span>\" => \"\"\n  \"<span class=sf-dump-key>CONTEXT_DOCUMENT_ROOT<\/span>\" => \"<span class=sf-dump-str title=\"24 characters\">\/home\/gs4bgu9db872\/badal<\/span>\"\n  \"<span class=sf-dump-key>SERVER_ADMIN<\/span>\" => \"<span class=sf-dump-str title=\"28 characters\">webmaster@badal.sahla-ad.com<\/span>\"\n  \"<span class=sf-dump-key>SCRIPT_FILENAME<\/span>\" => \"<span class=sf-dump-str title=\"41 characters\">\/home\/gs4bgu9db872\/badal\/public\/index.php<\/span>\"\n  \"<span class=sf-dump-key>REMOTE_PORT<\/span>\" => \"<span class=sf-dump-str title=\"5 characters\">58582<\/span>\"\n  \"<span class=sf-dump-key>REDIRECT_URL<\/span>\" => \"<span class=sf-dump-str title=\"15 characters\">\/public\/allbids<\/span>\"\n  \"<span class=sf-dump-key>SERVER_PROTOCOL<\/span>\" => \"<span class=sf-dump-str title=\"8 characters\">HTTP\/2.0<\/span>\"\n  \"<span class=sf-dump-key>REQUEST_METHOD<\/span>\" => \"<span class=sf-dump-str title=\"3 characters\">GET<\/span>\"\n  \"<span class=sf-dump-key>QUERY_STRING<\/span>\" => \"\"\n  \"<span class=sf-dump-key>REQUEST_URI<\/span>\" => \"<span class=sf-dump-str title=\"15 characters\">\/public\/allbids<\/span>\"\n  \"<span class=sf-dump-key>SCRIPT_NAME<\/span>\" => \"<span class=sf-dump-str title=\"17 characters\">\/public\/index.php<\/span>\"\n  \"<span class=sf-dump-key>PHP_SELF<\/span>\" => \"<span class=sf-dump-str title=\"17 characters\">\/public\/index.php<\/span>\"\n  \"<span class=sf-dump-key>REQUEST_TIME_FLOAT<\/span>\" => <span class=sf-dump-num>1643288978.7667<\/span>\n  \"<span class=sf-dump-key>REQUEST_TIME<\/span>\" => <span class=sf-dump-num>1643288978<\/span>\n<\/samp>]\n<\/pre><script>Sfdump(\"sf-dump-1784825390\", {\"maxDepth\":0})<\/script>\n", "request_cookies": "<pre class=sf-dump id=sf-dump-605228721 data-indent-pad=\"  \"><span class=sf-dump-note>array:7<\/span> [<samp data-depth=1 class=sf-dump-expanded>\n  \"<span class=sf-dump-key>_tccl_visitor<\/span>\" => <span class=sf-dump-const>null<\/span>\n  \"<span class=sf-dump-key>_tccl_visit<\/span>\" => <span class=sf-dump-const>null<\/span>\n  \"<span class=sf-dump-key>remember_account_59ba36addc2b2f9401580f014c7f58ea4e30989d<\/span>\" => \"<span class=sf-dump-str title=\"124 characters\">17|XUDDkA6qcJBl5PblJAVtWJqXzBnHaeRrJfZ7R5z2O6w88DXlP4z2fn4exmKE|$2y$10$\/ntr7ONa2KW93N027.o1Ne8D5I9Bi7U8I0wJknrhkdZgZZUR4YOve<\/span>\"\n  \"<span class=sf-dump-key>cookie_for_consent<\/span>\" => \"<span class=sf-dump-str>1<\/span>\"\n  \"<span class=sf-dump-key>remember_web_59ba36addc2b2f9401580f014c7f58ea4e30989d<\/span>\" => \"<span class=sf-dump-str title=\"123 characters\">2|cL0Xl3WGPTzxvDucS1wWm40mangUPjQlUM4paiVmsl4bAf7XeQHmClq10L3X|$2y$10$MP7gok5yCr20kSpnZmh3PO\/ZYkiZSGOJaz5ZRTIL0NZkJYNjkGjXy<\/span>\"\n  \"<span class=sf-dump-key>XSRF-TOKEN<\/span>\" => \"<span class=sf-dump-str title=\"40 characters\">HtnhadFgNS5BmPCwPrhFch454mVvPfZbD2QDyaRA<\/span>\"\n  \"<span class=sf-dump-key>botble_session<\/span>\" => \"<span class=sf-dump-str title=\"40 characters\">mnIVVhbavH96X2EA5tqXGJH6OCkyApJ4WX1GvSDU<\/span>\"\n<\/samp>]\n<\/pre><script>Sfdump(\"sf-dump-605228721\", {\"maxDepth\":0})<\/script>\n", "response_headers": "<pre class=sf-dump id=sf-dump-74333063 data-indent-pad=\"  \"><span class=sf-dump-note>array:8<\/span> [<samp data-depth=1 class=sf-dump-expanded>\n  \"<span class=sf-dump-key>cache-control<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"17 characters\">no-cache, private<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>date<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"29 characters\">Thu, 27 Jan 2022 13:09:38 GMT<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>cms-version<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"4 characters\">5.22<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>authorization-at<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"19 characters\">2022-01-26 20:25:40<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>activated-license<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"2 characters\">No<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>content-type<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"24 characters\">text\/html; charset=UTF-8<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>set-cookie<\/span>\" => <span class=sf-dump-note>array:2<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"428 characters\">XSRF-TOKEN=eyJpdiI6ImRYRVI0cm9xRXdBQ1pLOU1SdzF5SEE9PSIsInZhbHVlIjoidzVxMG1SL2N1MFY3KytnWkVyd0w0MjcyMzV1T3hKeWZxUWI4eG91R1ZCaktnWWlaWkk0L1hBVG1oR3VRazhNTXpaY2k3TENVeFBpdDk2MVVQS1VDK0hLdFRxTW9vcHFRbVhPS3ZYbDJPYm9vU1BRNFQvNHEraEZPa0JxT0YreXAiLCJtYWMiOiJlMDViYTQwMTk4ZWYzMDI1ODkzY2M0NzRjNTMyZDc3MDRkNzE0MDFmNzY2YTg3ODQ5Y2QxNDhiNDE1Mzc0YmIxIiwidGFnIjoiIn0%3D; expires=Thu, 27-Jan-2022 15:09:38 GMT; Max-Age=7200; path=\/; samesite=lax<\/span>\"\n    <span class=sf-dump-index>1<\/span> => \"<span class=sf-dump-str title=\"442 characters\">botble_session=eyJpdiI6InhhM0tKd2tCc0YvTW9mSEk4bS8wK2c9PSIsInZhbHVlIjoiRFNIZUIwSS9BWWtJVjlHbjN0RUpzSGkzYlo3dDNzckxyT1VIZmxpcVhXUHl5eHU3bWErWWg2SVptNUEvMHBZUVg3Z3c1L2FWcUVoUHQwaXRxdFprSFc3RHRDS3hWb3JtaWFIV2RWMDhucThrNGhkWnc2V0IwbkRjWGswSFJFbkQiLCJtYWMiOiIyOTcwNDcxODI3NTkxMTNiZDBmZmUyODMxNjk2MzIzODg5ZDA1Y2UzZjljODJkZGIwMTk1MGY4ZTg1ODQ2MzY3IiwidGFnIjoiIn0%3D; expires=Thu, 27-Jan-2022 15:09:38 GMT; Max-Age=7200; path=\/; httponly; samesite=lax<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>Set-Cookie<\/span>\" => <span class=sf-dump-note>array:2<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    <span class=sf-dump-index>0<\/span> => \"<span class=sf-dump-str title=\"400 characters\">XSRF-TOKEN=eyJpdiI6ImRYRVI0cm9xRXdBQ1pLOU1SdzF5SEE9PSIsInZhbHVlIjoidzVxMG1SL2N1MFY3KytnWkVyd0w0MjcyMzV1T3hKeWZxUWI4eG91R1ZCaktnWWlaWkk0L1hBVG1oR3VRazhNTXpaY2k3TENVeFBpdDk2MVVQS1VDK0hLdFRxTW9vcHFRbVhPS3ZYbDJPYm9vU1BRNFQvNHEraEZPa0JxT0YreXAiLCJtYWMiOiJlMDViYTQwMTk4ZWYzMDI1ODkzY2M0NzRjNTMyZDc3MDRkNzE0MDFmNzY2YTg3ODQ5Y2QxNDhiNDE1Mzc0YmIxIiwidGFnIjoiIn0%3D; expires=Thu, 27-Jan-2022 15:09:38 GMT; path=\/<\/span>\"\n    <span class=sf-dump-index>1<\/span> => \"<span class=sf-dump-str title=\"414 characters\">botble_session=eyJpdiI6InhhM0tKd2tCc0YvTW9mSEk4bS8wK2c9PSIsInZhbHVlIjoiRFNIZUIwSS9BWWtJVjlHbjN0RUpzSGkzYlo3dDNzckxyT1VIZmxpcVhXUHl5eHU3bWErWWg2SVptNUEvMHBZUVg3Z3c1L2FWcUVoUHQwaXRxdFprSFc3RHRDS3hWb3JtaWFIV2RWMDhucThrNGhkWnc2V0IwbkRjWGswSFJFbkQiLCJtYWMiOiIyOTcwNDcxODI3NTkxMTNiZDBmZmUyODMxNjk2MzIzODg5ZDA1Y2UzZjljODJkZGIwMTk1MGY4ZTg1ODQ2MzY3IiwidGFnIjoiIn0%3D; expires=Thu, 27-Jan-2022 15:09:38 GMT; path=\/; httponly<\/span>\"\n  <\/samp>]\n<\/samp>]\n<\/pre><script>Sfdump(\"sf-dump-74333063\", {\"maxDepth\":0})<\/script>\n", "session_attributes": "<pre class=sf-dump id=sf-dump-1341104221 data-indent-pad=\"  \"><span class=sf-dump-note>array:9<\/span> [<samp data-depth=1 class=sf-dump-expanded>\n  \"<span class=sf-dump-key>url<\/span>\" => []\n  \"<span class=sf-dump-key>_token<\/span>\" => \"<span class=sf-dump-str title=\"40 characters\">HtnhadFgNS5BmPCwPrhFch454mVvPfZbD2QDyaRA<\/span>\"\n  \"<span class=sf-dump-key>language<\/span>\" => \"<span class=sf-dump-str title=\"2 characters\">en<\/span>\"\n  \"<span class=sf-dump-key>_previous<\/span>\" => <span class=sf-dump-note>array:1<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    \"<span class=sf-dump-key>url<\/span>\" => \"<span class=sf-dump-str title=\"41 characters\">https:\/\/badal.sahla-ad.com\/public\/allbids<\/span>\"\n  <\/samp>]\n  \"<span class=sf-dump-key>_flash<\/span>\" => <span class=sf-dump-note>array:2<\/span> [<samp data-depth=2 class=sf-dump-compact>\n    \"<span class=sf-dump-key>old<\/span>\" => []\n    \"<span class=sf-dump-key>new<\/span>\" => []\n  <\/samp>]\n  \"<span class=sf-dump-key>login_account_59ba36addc2b2f9401580f014c7f58ea4e30989d<\/span>\" => <span class=sf-dump-num>17<\/span>\n  \"<span class=sf-dump-key>admin-theme<\/span>\" => \"<span class=sf-dump-str title=\"7 characters\">default<\/span>\"\n  \"<span class=sf-dump-key>login_web_59ba36addc2b2f9401580f014c7f58ea4e30989d<\/span>\" => <span class=sf-dump-num>2<\/span>\n  \"<span class=sf-dump-key>PHPDEBUGBAR_STACK_DATA<\/span>\" => []\n<\/samp>]\n<\/pre><script>Sfdump(\"sf-dump-1341104221\", {\"maxDepth\":0})<\/script>\n" } }, "X775367a88bcbd644d5a4034effbdb541");

</script>
</body>
<script>'undefined' === typeof _trfq || (window._trfq = []); 'undefined' === typeof _trfd && (window._trfd = []), _trfd.push({ 'tccl.baseHost': 'secureserver.net' }), _trfd.push({ 'ap': 'cpsh' }, { 'server': 'a2plcpnl0014' }, { 'id': '5451430' }) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script>
<script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script>

</html>
