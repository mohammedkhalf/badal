<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, user-scalable=1" name="viewport" />
    <meta name="csrf-token" content="eiPSpRHVieAuQ0bg4Vy3090fyrgFkvnBxrM7EEs1">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Cairo:300,400,600,700" rel="stylesheet" type="text/css">

    <style>
        :root {
            --primary-color: #2b4db9;
            --font-body: Cairo, sans-serif;
            --font-heading: Cairo, sans-serif;
        }
    </style>
    
    <link rel="shortcut icon" href="/public/storage/badel-logo-03.png">
    <title>الرئيسية</title>
    <meta name="description" content="hello">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:site_name" content="">
    <meta property="og:image" content="/public/storage/login-background.jpg">
    <meta property="og:title" content="الرئيسية">
    <meta property="og:description" content="hello">
    <meta property="og:url" content="/public/alryysy">
    <meta property="og:type" content="article">
    <meta name="twitter:title" content="الرئيسية">
    <meta name="twitter:description" content="hello">
    <link media="all" type="text/css" rel="stylesheet" href="/public/vendor/core/plugins/language/css/language-public.css?v=1.0.0">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/animation.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/bootstrap/bootstrap.min.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/ion.rangeSlider.min.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/dropzone.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/select2.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/slick.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/slick-theme.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/font-awesome.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/icofont.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/light-box.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/line-icon.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/themify.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/css/style.css?v=1.11.0">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/css/rtl-style.css?v=1.11.0">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/plugins/leaflet.css">
    <link media="all" type="text/css" rel="stylesheet" href="/public/themes/resido/css/style.integration.css?v=1645436843">
    <script src="/public/themes/resido/plugins/jquery.min.js"></script>
    <link rel="alternate" href="/public/en" hreflang="en" />
    <link type="application/atom+xml" rel="alternate" title="Properties feed" href="/public/feed/properties">
    <link type="application/atom+xml" rel="alternate" title="Properties feed" href="/public/en/feed/properties">
    <link type="application/atom+xml" rel="alternate" title="Posts feed" href="/public/feed/posts">
    <link type="application/atom+xml" rel="alternate" title="Posts feed" href="/public/en/feed/posts">
    <link rel='stylesheet' type='text/css' property='stylesheet' href='/public/_debugbar/assets/stylesheets?v=1637196972&theme=auto'>
    <script type='text/javascript' src='/public/_debugbar/assets/javascript?v=1637196972'></script>
</head>
<style>
    .one-slider-buttons div{
        background: rgb(18,102,227);
        background: linear-gradient(90deg, rgba(18,102,227,1) 0%, rgba(48,151,228,1) 79%);
        min-height: 100vh;
        text-align: center;
    }
    .one-slider-buttons img{
        margin-bottom:20px;
        margin-top:50px;
    }
    
    .skip-splash {
        padding-top:150px;
        
        color:#fff;
    }
    
    
</style>
<body>

<div class="my-3 one-slider-buttons">
    <div class="text-white">
        <img src="/public/storage/splash2.png" class="w-100"/>
        <h3 class="text-white">عمليات البدل صارت اسهل</h3>
        <p>دون الحاجة لمكاتب العقار أو سماسرة العقار
            <br/> بدون عمولات
        </p>
    </div>
    <div class="text-white">
        <img src="/public/storage/splash1.png" class="w-100"/>
        <h3 class="text-white">عمليات البدل صارت اسهل</h3>
        <p>دون الحاجة لمكاتب العقار أو سماسرة العقار
            <br/> بدون عمولات
        </p>
    </div>
    <div class="text-white" style="background-image: url('/public/storage/splash3.png');background-size: cover;display: flex; align-items: center; justify-content: center; flex-direction: column;">
        <h3 class="text-white">الأبلكيشن الاول في الكويت </h3>
        <p>لتنظيم معاملات البدل السكني بين العائلات الكويتية
        </p>
        
         <a href="/public/alryysy"><h2 class="skip-splash"><i class="fas fa-arrow-right"></i>تخطى</h3> </a>
        
    </div>
    
            
    
</div>
<link media="all" type="text/css" rel="stylesheet" href="/public/vendor/core/plugins/simple-slider/libraries/owl-carousel/owl.carousel.css?v=1.0.0">
<link media="all" type="text/css" rel="stylesheet" href="/public/vendor/core/plugins/simple-slider/css/simple-slider.css?v=1.0.0">
<script src="/public/themes/resido/plugins/bootstrap/popper.min.js"></script>
<script src="/public/themes/resido/plugins/bootstrap/bootstrap.min.js"></script>
<script src="/public/themes/resido/plugins/rangeslider.js"></script>
<script src="/public/themes/resido/plugins/select2.min.js"></script>
<script src="/public/themes/resido/plugins/jquery.magnific-popup.min.js"></script>
<script src="/public/themes/resido/plugins/slick.js"></script>
<script src="/public/themes/resido/plugins/slider-bg.js"></script>
<script src="/public/themes/resido/plugins/lightbox.js"></script>
<script src="/public/themes/resido/plugins/imagesloaded.js"></script>
<script src="/public/themes/resido/plugins/lazyload.min.js"></script>
<script src="/public/themes/resido/js/components.js?v=1.11.0"></script>
<script src="/public/themes/resido/js/wishlist.js?v=1.11.0"></script>
<script src="/public/themes/resido/js/app.js?v=1.11.0"></script>
<script src="/public/themes/resido/plugins/leaflet.js"></script>
<script src="/public/themes/resido/plugins/leaflet.markercluster-src.js"></script>
<script src="/public/vendor/core/plugins/language/js/language-public.js?v=1.0.0"></script>
<script src="/public/vendor/core/plugins/simple-slider/libraries/owl-carousel/owl.carousel.js?v=1.0.0"></script>
<script src="/public/vendor/core/plugins/simple-slider/js/simple-slider.js?v=1.0.0"></script>
</body>
</html>
